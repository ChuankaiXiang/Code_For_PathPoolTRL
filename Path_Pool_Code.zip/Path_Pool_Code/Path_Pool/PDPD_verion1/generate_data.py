import os

from utils.data_utils import check_extension, save_dataset
import torch
import pickle
import argparse
import math
import pandas as pd
import numpy as np
import random

def generate_hcvrp_data(dataset_size,
            cust_count,
            charge_station_count,
            depot_count,
            drone_count,
            drone_capa,
            drone_speed,
            drone_battery_capacity,
            drone_and_battery_weight,
            energy_consumption_env_factor,
            cust_loc_range,
            package_weight_range,
            horizon,
            service_time_range,
            tw_ratio,
            cust_tw_range,
            deg_of_dy,
            d_early_ratio,
            ):
    data = []
    path = 'data/transportation_nodes/node.csv'
    for seed in range(24601, 24621):
        torch.manual_seed(seed)

        # locations = pd.read_csv(path, header=0,
        #                         usecols=["Longitude", "Latitude"
        #                                  ]).values
        # locations = np.array(locations)
        # # 先一步标准化一下下
        # locations[:, 0] = locations[:, 0] - 73.5
        # dy_drone_count = int(drone_count * deg_of_drone_dy)
        sel_node_num = cust_count * 2 + charge_station_count + depot_count
        #
        # selected_points = locations[:sel_node_num, :]
        # for i in range(sel_node_num, len(locations)):
        #     r = random.randint(0, i)
        #     if r < sel_node_num:
        #         selected_points[r, :] = locations[i, :]
        #
        # nodes = torch.from_numpy(selected_points).float()
        nodes = torch.randint(*cust_loc_range, (sel_node_num, 2), dtype=torch.float)

        locs = nodes[None,:cust_count * 2, :]
        depot = nodes[None,cust_count * 2: cust_count * 2 + depot_count, :]
        charge_station = nodes[None,cust_count * 2 + depot_count:, :]

        package_weight_P = torch.randint(*package_weight_range, (dataset_size,cust_count, 1), dtype=torch.float)
        package_weight_D = - package_weight_P
        package_weight = torch.cat((package_weight_P, package_weight_D), 1)
        service_time = torch.randint(*service_time_range, (dataset_size,cust_count * 2, 1), dtype=torch.float)
        drone_and_battery_weight_ = torch.tensor(drone_and_battery_weight, dtype=torch.float).expand(1)
        energy_consumption_env_factor = torch.tensor(energy_consumption_env_factor, dtype=torch.float).expand(1)

        if isinstance(deg_of_dy, float):
            is_dyn = torch.empty((dataset_size,cust_count, 1)).bernoulli_(deg_of_dy)
        elif len(deg_of_dy) == 1:
            is_dyn = torch.empty(deg_of_dy).bernoulli_(deg_of_dy[0])
        else:  # tuple of float
            ratio = torch.tensor(deg_of_dy)[torch.randint(0, len(deg_of_dy), (1,), dtype=torch.int64)]
            is_dyn = ratio[:, None].expand((dataset_size,cust_count, 1)).bernoulli()

        if isinstance(d_early_ratio, float):
            is_dyn_e = torch.empty((dataset_size,cust_count, 1)).bernoulli_(d_early_ratio)
        elif len(d_early_ratio) == 1:
            is_dyn_e = torch.empty((dataset_size,cust_count, 1)).bernoulli_(d_early_ratio[0])
        else:
            ratio = torch.tensor(d_early_ratio)[
                torch.randint(0, len(d_early_ratio), (1,), dtype=torch.int64)
            ]
            is_dyn_e = ratio[:, None].expand((dataset_size,cust_count, 1)).bernoulli()

        pick_aprs = is_dyn * is_dyn_e * torch.randint(1, horizon // 3 + 1, (dataset_size,cust_count, 1), dtype=torch.float) \
                    + is_dyn * (1 - is_dyn_e) * torch.randint(horizon // 3 + 1, 2 * horizon // 3 + 1, (dataset_size,cust_count, 1),
                                                              dtype=torch.float)
        del_aprs = pick_aprs
        aprs = torch.cat((pick_aprs, del_aprs), 1)

        if isinstance(tw_ratio, float):
            has_tw = torch.empty((dataset_size,cust_count, 1)).bernoulli_(tw_ratio)
        elif len(tw_ratio) == 1:
            has_tw = torch.empty((dataset_size,cust_count, 1)).bernoulli_(tw_ratio[0])
        else:  # tuple of float
            ratio = torch.tensor(tw_ratio)[torch.randint(0, len(tw_ratio), (1,), dtype=torch.int64)]
            has_tw = ratio[:, None].expand((dataset_size,cust_count, 1)).bernoulli()

        tws_pick = (1 - has_tw) * torch.full((dataset_size,cust_count, 1), horizon) \
                   + has_tw * torch.randint(*cust_tw_range, (dataset_size,cust_count, 1), dtype=torch.float)
        tws_deli = (1 - has_tw) * torch.full((dataset_size,cust_count, 1), horizon) \
                   + has_tw * torch.randint(*cust_tw_range, (dataset_size,cust_count, 1), dtype=torch.float)
        tws = torch.cat((tws_pick, tws_deli), 1)

        #  这里要改一下，后面可能需要重新考虑depot的数量
        centroid = torch.mean(depot, dim=1)
        pick_tts = (centroid[:,None, None, :] - locs[:,:cust_count, None, :]).pow(2).sum(-1).pow(0.5) / drone_speed
        del_tts_ = (locs[:,:cust_count, None, :] - locs[:,cust_count:, None, :]).pow(2).sum(-1).pow(0.5) / drone_speed
        del_tts = pick_tts + del_tts_

        pick_rdys = has_tw[:,:cust_count, :] * (aprs[:,:cust_count, :] + torch.rand(dataset_size,cust_count, 1) * (
                    horizon - torch.max(pick_tts + service_time[:,:cust_count, :], tws[:,:cust_count, :]) - aprs[:,
                                                                                                        :cust_count,
                                                                                                        :]))

        del_rdys = pick_rdys + del_tts
        rdys = torch.cat((pick_rdys, del_rdys), 1)

        rdys.floor_()
        ldts = rdys + tws
        # ldts_index = ldts>480
        # ldts[ldts_index] = 480

        ##normalize###
        loc_scl, loc_off = torch.cat((locs, charge_station, depot), 1)[:,:, :].max().item(), torch.cat(
            (locs, charge_station, depot), 1)[:,:, :].min().item()
        loc_scl -= loc_off
        t_scl = ldts[:,:, :].max().item()

        locs -= loc_off
        locs /= loc_scl
        charge_station -= loc_off
        charge_station /= loc_scl
        depot -= loc_off
        depot /= loc_scl

        package_weight /= drone_capa
        drone_and_battery_weight_ /= drone_capa

        service_time /= t_scl
        rdys /= t_scl
        ldts /= t_scl
        aprs /= t_scl

        drone_speed = torch.tensor(drone_speed, dtype=torch.float32).expand(1)
        drone_count = torch.tensor(drone_count, dtype=torch.float32).expand(1)

        thedata = list(zip(locs.tolist(),
                    charge_station.tolist(),
                    depot.tolist(),
                    drone_count.tolist(),
                    package_weight.tolist(),
                    drone_and_battery_weight_.tolist(),
                    energy_consumption_env_factor.tolist(),
                    service_time.tolist(),
                    rdys.tolist(),
                    ldts.tolist(),
                    aprs.tolist(),
                    drone_speed.tolist()
                           ))
        data.append(thedata)
    t = np.array(data)
    data = t.reshape(20, 12)

    return data


if __name__ == "__main__":

    # CUST_COUNT = 25
    # CUST_COUNT = 50
    CUST_COUNT = 25
    # CUST_COUNT = 160
    # CUST_COUNT = 70
    # CUST_COUNT = 5


    # Drone_count = 5
    # Drone_count = 10
    Drone_count = 5
    # Drone_count = 80
    # Drone_count = 20
    # Drone_count = 2


    Charge_station_count = 6
    Depot_count = 5
    Drone_CAPA = 100
    Drone_battery_capacity = 100  # 后面还得调整
    Drone_and_battery_weight = 10
    # Energy_consumption_env_factor = 0.5
    Energy_consumption_env_factor = 0.5
    Drone_SPEED = 5
    HORIZON = 480
    MIN_CUST_COUNT = None
    LOC_RANGE = (0, 101)
    Package_weigh_RANGE = (30, 40)
    DUR_RANGE = (10, 31)
    TW_RATIO = (0.25, 0.5, 0.75, 1.0)
    TW_RANGE = (30, 91)
    DEG_OF_DYN = 0.3
    APPEAR_EARLY_RATIO = (0.0, 0.5, 0.75, 1.0)

    parser = argparse.ArgumentParser()
    parser.add_argument("--filename", help="Filename of the dataset to create (ignores datadir)")
    parser.add_argument("--dataset_size", type=int, default=1, help="1/10 Size of the dataset")

    group = parser.add_argument_group("Data generation parameters")
    group.add_argument('--graph_size', "-n", type=int, default=CUST_COUNT)
    group.add_argument('--charge_station_count', "-l", type=int, default=Charge_station_count)
    group.add_argument('--depot_count', "-k", type=int, default=Depot_count)
    group.add_argument('--drone_count', "-m", type=int, default=Drone_count)
    group.add_argument("--drone_capa", type=int, default=Drone_CAPA)
    group.add_argument("--drone_battery_capacity", type=int, default=Drone_battery_capacity)
    group.add_argument("--drone_and_battery_weight", type=int, default=Drone_and_battery_weight)
    group.add_argument("--energy_consumption_env_factor", type=int, default=Energy_consumption_env_factor)
    group.add_argument("--drone_speed", type=int, default=Drone_SPEED)
    group.add_argument("--horizon", type=int, default=HORIZON)
    group.add_argument("--min_cust_count", type=int, default=MIN_CUST_COUNT)
    group.add_argument("--loc_range", type=int, nargs=2, default=LOC_RANGE)
    group.add_argument("--package_weight_range", type=int, nargs=2, default=Package_weigh_RANGE)
    group.add_argument("--service_time_range", type=int, nargs=2, default=DUR_RANGE)
    group.add_argument("--tw_ratio", type=float, nargs='*', default=TW_RATIO)
    group.add_argument("--tw_range", type=int, nargs=2, default=TW_RANGE)
    group.add_argument("--deg_of_dyna", type=float, nargs='*', default=DEG_OF_DYN)
    group.add_argument("--appear_early_ratio", type=float, nargs='*', default=APPEAR_EARLY_RATIO)

    opts = parser.parse_args()
    data_dir = 'data'
    problem = 'MVPDPC_cus_drone_dy0_3'
    datadir = os.path.join(data_dir, problem)
    os.makedirs(datadir, exist_ok=True)
    seed = 24610
    np.random.seed(seed)
    print(opts.dataset_size, opts.graph_size)
    filename = os.path.join(datadir, '{}_v{}_{}_CS{}_Dep{}_seed{}.pkl'.format(problem, opts.drone_count, opts.graph_size,opts.charge_station_count,opts.depot_count, seed))

    dataset = generate_hcvrp_data(opts.dataset_size,
                                  opts.graph_size,
                                  opts.charge_station_count,
                                  opts.depot_count,
                                  opts.drone_count,
                                  opts.drone_capa,
                                  opts.drone_speed,
                                  opts.drone_battery_capacity,
                                  opts.drone_and_battery_weight,
                                  opts.energy_consumption_env_factor,
                                  opts.loc_range,
                                  opts.package_weight_range,
                                  opts.horizon,
                                  opts.service_time_range,
                                  opts.tw_ratio,
                                  opts.tw_range,
                                  opts.deg_of_dyna,
                                  opts.appear_early_ratio)
    print(dataset[0])
    save_dataset(dataset, filename)



