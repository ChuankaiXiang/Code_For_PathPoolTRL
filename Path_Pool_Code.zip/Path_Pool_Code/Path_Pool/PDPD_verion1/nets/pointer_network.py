import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.autograd import Variable
import math
import numpy as np
from utils.functions import sample_many


class Encoder(nn.Module):
    """Maps a graph represented as an input sequence
    to a hidden vector"""
    def __init__(self, input_dim, hidden_dim):
        super(Encoder, self).__init__()
        self.hidden_dim = hidden_dim
        self.lstm = nn.LSTM(input_dim, hidden_dim)
        self.init_hx, self.init_cx = self.init_hidden(hidden_dim)

    def forward(self, x, hidden):
        output, hidden = self.lstm(x, hidden)
        return output, hidden
    
    def init_hidden(self, hidden_dim):
        """Trainable initial hidden state"""
        std = 1. / math.sqrt(hidden_dim)
        enc_init_hx = nn.Parameter(torch.FloatTensor(hidden_dim))
        enc_init_hx.data.uniform_(-std, std)

        enc_init_cx = nn.Parameter(torch.FloatTensor(hidden_dim))
        enc_init_cx.data.uniform_(-std, std)
        return enc_init_hx, enc_init_cx


class Attention(nn.Module):
    """A generic attention module for a decoder in seq2seq"""
    def __init__(self, dim, use_tanh=False, C=10):
        super(Attention, self).__init__()
        self.use_tanh = use_tanh
        self.project_query = nn.Linear(dim, dim)
        self.project_ref = nn.Conv1d(dim, dim, 1, 1)
        self.C = C  # tanh exploration
        self.tanh = nn.Tanh()

        self.v = nn.Parameter(torch.FloatTensor(dim))
        self.v.data.uniform_(-(1. / math.sqrt(dim)), 1. / math.sqrt(dim))
        
    def forward(self, query, ref):
        """
        Args: 
            query: is the hidden state of the decoder at the current
                time step. batch x dim
            ref: the set of hidden states from the encoder. 
                sourceL x batch x hidden_dim
        """
        # ref is now [batch_size x hidden_dim x sourceL]
        ref = ref.permute(1, 2, 0)
        q = self.project_query(query).unsqueeze(2)  # batch x dim x 1
        e = self.project_ref(ref)  # batch_size x hidden_dim x sourceL 
        # expand the query by sourceL
        # batch x dim x sourceL
        expanded_q = q.repeat(1, 1, e.size(2)) 
        # batch x 1 x hidden_dim
        v_view = self.v.unsqueeze(0).expand(
                expanded_q.size(0), len(self.v)).unsqueeze(1)
        # [batch_size x 1 x hidden_dim] * [batch_size x hidden_dim x sourceL]
        u = torch.bmm(v_view, self.tanh(expanded_q + e)).squeeze(1)
        if self.use_tanh:
            logits = self.C * self.tanh(u)
        else:
            logits = u  
        return e, logits


class Decoder(nn.Module):
    def __init__(self, 
            embedding_dim,
            hidden_dim,
            tanh_exploration,
            use_tanh,
            n_glimpses=1,
            mask_glimpses=True,
            mask_logits=True):
        super(Decoder, self).__init__()

        self.embedding_dim = embedding_dim
        self.hidden_dim = hidden_dim
        self.n_glimpses = n_glimpses
        self.mask_glimpses = mask_glimpses
        self.mask_logits = mask_logits
        self.use_tanh = use_tanh
        self.tanh_exploration = tanh_exploration
        self.decode_type = None  # Needs to be set explicitly before use

        self.lstm = nn.LSTMCell(embedding_dim, hidden_dim)
        self.pointer = Attention(hidden_dim, use_tanh=use_tanh, C=tanh_exploration)
        self.glimpse = Attention(hidden_dim, use_tanh=False)
        self.sm = nn.Softmax(dim=1)



    def recurrence(self, x, h_in, mask, context):



        logits, h_out = self.calc_logits(x, h_in, mask, context, self.mask_glimpses, self.mask_logits)

        # Calculate log_softmax for better numerical stability
        log_p = torch.log_softmax(logits, dim=1)



        return h_out, log_p

    def calc_logits(self, x, h_in, logit_mask, context, mask_glimpses=None, mask_logits=None):

        if mask_glimpses is None:
            mask_glimpses = self.mask_glimpses

        if mask_logits is None:
            mask_logits = self.mask_logits

        hy, cy = self.lstm(x, h_in)
        g_l, h_out = hy, (hy, cy)

        for i in range(self.n_glimpses):
            ref, logits = self.glimpse(g_l, context)
            # For the glimpses, only mask before softmax so we have always an L1 norm 1 readout vector
            if mask_glimpses:
                logits[logit_mask.squeeze()] = -np.inf
            # [batch_size x h_dim x sourceL] * [batch_size x sourceL x 1] =
            # [batch_size x h_dim x 1]
            g_l = torch.bmm(ref, self.sm(logits).unsqueeze(2)).squeeze(2)
        _, logits = self.pointer(g_l, context)

        # Masking before softmax makes probs sum to one
        if mask_logits:
            logits[logit_mask.squeeze()] = -np.inf

        return logits, h_out

    def forward(self, decoder_input,  hidden, context,state,veh):

        mask, non_cus_index = state.get_mask(veh)


        hidden, log_p= self.recurrence(decoder_input, hidden, mask, context)






        return  log_p[:,None,:], mask,non_cus_index,hidden

    def decode(self, probs, mask):
        if self.decode_type == "greedy":
            _, idxs = probs.max(1)
            assert not mask.gather(1, idxs.unsqueeze(-1)).data.any(), \
                "Decode greedy: infeasible action has maximum probability"
        elif self.decode_type == "sampling":
            idxs = probs.multinomial(1).squeeze(1)
            # Check if sampling went OK, can go wrong due to bug on GPU
            while mask.gather(1, idxs.unsqueeze(-1)).data.any():
                print(' [!] resampling due to race condition')
                idxs = probs.multinomial().squeeze(1)
        else:
            assert False, "Unknown decode type"

        return idxs


class CriticNetworkLSTM(nn.Module):
    """Useful as a baseline in REINFORCE updates"""
    def __init__(self,
            embedding_dim,
            hidden_dim,
            n_process_block_iters,
            tanh_exploration,
            use_tanh):
        super(CriticNetworkLSTM, self).__init__()
        
        self.hidden_dim = hidden_dim
        self.n_process_block_iters = n_process_block_iters

        self.encoder = Encoder(embedding_dim, hidden_dim)
        
        self.process_block = Attention(hidden_dim, use_tanh=use_tanh, C=tanh_exploration)
        self.sm = nn.Softmax(dim=1)
        self.decoder = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, 1)
        )

    def forward(self, inputs):
        """
        Args:
            inputs: [embedding_dim x batch_size x sourceL] of embedded inputs
        """
        inputs = inputs.transpose(0, 1).contiguous()

        encoder_hx = self.encoder.init_hx.unsqueeze(0).repeat(inputs.size(1), 1).unsqueeze(0)
        encoder_cx = self.encoder.init_cx.unsqueeze(0).repeat(inputs.size(1), 1).unsqueeze(0)
        
        # encoder forward pass
        enc_outputs, (enc_h_t, enc_c_t) = self.encoder(inputs, (encoder_hx, encoder_cx))
        
        # grab the hidden state and process it via the process block 
        process_block_state = enc_h_t[-1]
        for i in range(self.n_process_block_iters):
            ref, logits = self.process_block(process_block_state, enc_outputs)
            process_block_state = torch.bmm(ref, self.sm(logits).unsqueeze(2)).squeeze(2)
        # produce the final scalar output
        out = self.decoder(process_block_state)
        return out


class PointerNetwork(nn.Module):

    def __init__(self,
                 embedding_dim,
                 hidden_dim,
                 obj,
                 num_veh_,
                 problem,
                 n_encode_layers=None,
                 tanh_clipping=10.,
                 mask_inner=True,
                 mask_logits=True,
                 normalization=None,
                 shrink_size=None,
                 **kwargs):
        super(PointerNetwork, self).__init__()

        self.problem = problem
        self.embedding_dim = embedding_dim
        self.hidden_dim = hidden_dim
        self.input_dim = 7
        self.feed_forward_hidden = 512
        self.shrink_size = shrink_size
        self.decode_type = None
        self.temp = 1.0

        self.encoder = Encoder(
            embedding_dim,
            hidden_dim)

        self.decoder = Decoder(
            embedding_dim,
            hidden_dim,
            tanh_exploration=tanh_clipping,
            use_tanh=tanh_clipping > 0,
            n_glimpses=1,
            mask_glimpses=mask_inner,
            mask_logits=mask_logits
        )

        # Trainable initial hidden states
        std = 1. / math.sqrt(embedding_dim)
        self.obj = obj
        self.embedding = nn.Parameter(torch.FloatTensor(self.input_dim, embedding_dim))
        self.embedding.data.uniform_(-std, std)
        self.FF_veh_1 = nn.Sequential(
            nn.Linear(self.embedding_dim * 2, self.embedding_dim),
            nn.Linear(self.embedding_dim, self.feed_forward_hidden),
            nn.ReLU(),
            nn.Linear(self.feed_forward_hidden, 1)
        )

        self.veh1_embed = nn.Linear(2, self.embedding_dim)

        self.init_embed_start = nn.Linear(7, embedding_dim)
        self.init_embed_pick = nn.Linear(7, embedding_dim)  # the node_dim for embed_pick is 4, x,y,p,d ?
        self.init_embed_delivery = nn.Linear(7, embedding_dim)


    def set_decode_type(self, decode_type,temp=None):
        self.decoder.decode_type = decode_type
        self.decode_type = decode_type
        if temp is not None:  # Do not change temperature if not provided
            self.temp = temp


    def forward(self, inputs, return_pi=False):





        embedded_inputs = self._init_embed(inputs)


        # query the actor net for the input indices
        # making up the output, and the pointer attn
        _log_p, log_p_veh, pi, veh_list, tour, acc_late, acc_lengths,acc_subs = self._inner(inputs,embedded_inputs)

        cost,tour_cost,late_cost,subs,mask = self.problem.get_costs(inputs, self.obj, pi, tour, acc_late,acc_subs,acc_lengths)
        # Log likelyhood is calculated within the model since returning it per action does not work well with
        # DataParallel since sequences can be of different lengths
        ll, ll_veh = self._calc_log_likelihood(_log_p, log_p_veh, pi, mask, veh_list)
        if return_pi:
            return cost, tour_cost,late_cost,subs,ll, ll_veh

        return cost, tour_cost,late_cost,subs,ll, ll_veh

    def _calc_log_likelihood(self, _log_p, _log_p_veh, a, mask, veh_list):

        log_p = _log_p.gather(2, torch.tensor(a).unsqueeze(-1)).squeeze(-1)
        log_p_veh = _log_p_veh.gather(2, torch.tensor(veh_list).cuda().unsqueeze(-1)).squeeze(-1)

        # Optional: mask out actions irrelevant to objective so they do not get reinforced
        if mask is not None:
            log_p[mask] = 0
            log_p_veh[mask] = 0
        assert (log_p > -1000).data.all(), "Logprobs should not be -inf, check sampling procedure!"
        assert (log_p_veh > -1000).data.all(), "Logprobs should not be -inf, check sampling procedure!"

        # Calculate log_likelihood
        return log_p.sum(1), log_p_veh.sum(1)  # [batch_size]

    def select_veh(self, state,  embeddings):
        current_node = state.get_current_node()
        tour_dis = state.lengths[:,:,None]
        cur_time = state.veh_cur_time

        batch_size, _, embed_dim = embeddings.size()
        _, num_veh = current_node.size()

        crrent_loc_embedding = embeddings.gather(1,current_node[:, :, None].expand(embeddings.size(0), num_veh, embeddings.size(-1)))


        veh_FF = []
        for i in range(num_veh):
            veh = self.veh1_embed(torch.cat((tour_dis[:, i, :], cur_time[:, i, :]), -1))
            veh_context = torch.cat((veh, crrent_loc_embedding[:,i,:]), -1)
            veh_FF_= self.FF_veh_1(veh_context)[:,None,:]

            veh_FF.append(veh_FF_)
        v_context = torch.cat(veh_FF ,-1).squeeze()

        # 标记无处可去的车辆，选择车的时候不要选该车辆
        veh_mask = state.get_veh_mask(num_veh)
        v_context[veh_mask] = -math.inf

        log_veh = F.log_softmax(v_context, dim=1)


        if self.decode_type == "greedy":
            veh = torch.max(F.softmax(v_context, dim=1), dim=1)[1]
        elif self.decode_type == "sampling":
            veh = F.softmax(v_context, dim=1).multinomial(1).squeeze(-1)

        return veh, log_veh

    def _select_node(self, probs, mask, state, veh, sequences):  # probs, mask: [batch_size, graph_size]
        assert (probs == probs).all(), "Probs should not contain any nans"

        selected = (state.get_current_node()).clone()
        batch_size, _ = (state.get_current_node()).size()

        if self.decode_type == "greedy":
            _, selected[torch.arange(batch_size), veh] = probs.max(1)
            assert not mask.gather(-1,selected[torch.arange(batch_size), veh].unsqueeze(-1)).data.any(), "Decode greedy: infeasible action has maximum probability"

        elif self.decode_type == "sampling":
            selected[torch.arange(batch_size), veh] = probs.multinomial(1).squeeze(
                1)  # [batch_size]

            # Check if sampling went OK, can go wrong due to bug on GPU
            # See https://discuss.pytorch.org/t/bad-behavior-of-multinomial-function/10232
            while mask.gather(-1, selected[torch.arange(batch_size), veh].unsqueeze(-1)).data.any():
                print('Sampled bad values, resampling!')
                selected[torch.arange(batch_size), veh] = probs.multinomial(1).squeeze(1)

        else:
            assert False, "Unknown decode type"
        return selected

    def _init_embed(self, input):


        START_FEATURE_SIZE = 7

        cus = input['locs']  # 512*graph_size*2
        dems = input['dems']
        rdys = input['rdys']
        ldts = input['ldts']
        durs = input['durs']
        aprs = input['aprs']
        batch_size = cus.size(0)

        start = input['veh_start']  # 512*veh_num*2
        veh_num = start.size(1)
        cus_num = int(cus.size(1) / 2)

        start_feature = torch.zeros((batch_size, veh_num, START_FEATURE_SIZE), device=start.device)
        start_feature[:, :, :2] = start
        start_feature[:, :, 4] = 1

        pick_feature = torch.cat((cus[:, :cus_num, :], dems[:, :cus_num, :], rdys[:, :cus_num, :],
                                  ldts[:, :cus_num, :], durs[:, :cus_num, :], aprs[:, :cus_num, :]), -1)
        delivery_feature = torch.cat((cus[:, cus_num:, :], dems[:, cus_num:, :], rdys[:, cus_num:, :],
                                      ldts[:, cus_num:, :], durs[:, cus_num:, :], aprs[:, :cus_num, :]), -1)

        embed_start = self.init_embed_start(start_feature)
        embed_pick = self.init_embed_pick(pick_feature)
        embed_delivery = self.init_embed_delivery(delivery_feature)

        return torch.cat([embed_start, embed_pick, embed_delivery], 1)


    def _inner(self, input, embeddings):

        embeddings = embeddings.transpose(0, 1)

        state = self.problem.make_state(input)  # 初始化状态
        current_node = state.get_current_node()
        batch_size, num_veh = current_node.size()

        outputs = []
        outputs_veh = []
        sequences = []
        tour = [[] for _ in range(num_veh)]

        encoder_hx = encoder_cx = Variable(
            torch.zeros(1, embeddings.size(1), self.encoder.hidden_dim, out=embeddings.data.new()),
            requires_grad=False
        )
        enc_h, (enc_h_t, enc_c_t) = self.encoder(embeddings, (encoder_hx, encoder_cx))
        state = state._init_h_c_t(enc_h_t[-1], enc_c_t[-1])

        j = 0
        veh_list = []
        while not (self.shrink_size is None and state.all_finished()):
            veh, log_p_veh = self.select_veh(state, enc_h.transpose(0, 1))  # [batch_size, 1]
            veh_list.append(veh.tolist())
            ht_ct = (state.get_h_c_t(veh))
            pre_as = state.get_current_node()
            veh_pre_a = pre_as.gather(1,veh[:,None].expand(pre_as.size(0),1))
            decoder_input = embeddings.transpose(0,1).gather(1,veh_pre_a[:,:,None].expand(embeddings.size(1),1,embeddings.size(2))).squeeze()

            log_p, mask, non_cus_index,hidden = self.decoder(decoder_input,ht_ct,enc_h,state,veh)


            selected = self._select_node(log_p.exp()[:, 0, :], mask[:, 0, :], state, veh,sequences)
            state = state.update_hidden(veh,hidden)
            state = state.update(selected, veh, non_cus_index)

            # Now make log_p, selected desired output size by 'unshrinking'
            if self.shrink_size is not None and state.ids.size(0) < batch_size:
                log_p_, selected_ = log_p, selected
                log_p = log_p_.new_zeros(batch_size, *log_p_.size()[1:])
                selected = selected_.new_zeros(batch_size)

                log_p[state.ids[:, 0]] = log_p_
                selected[state.ids[:, 0]] = selected_
            # Collect output of step
            outputs.append(log_p[:, 0, :])
            outputs_veh.append(log_p_veh)

            sequences.append(selected[torch.arange(batch_size), veh])
            for i in range(num_veh):
                tour[i].append(selected[:, i])

            j += 1
        veh_list = torch.tensor(veh_list).transpose(0, 1)
        acc_late = state.get_acc_late()
        acc_subs = state.get_acc_subs()
        acc_lengths = state.get_acc_lengths()
        # output:[batch_size, solu_len, graph_size+1], sequences: [batch_size, tour_len]
        return torch.stack(outputs, 1), torch.stack(outputs_veh, 1), torch.stack(sequences, -1).squeeze(-2), veh_list, \
               tour, acc_late, acc_lengths, acc_subs

    def sample_many(self, input, batch_rep=1, iter_rep=1):
        """
        :param input: (batch_size, graph_size, node_dim) input node features
        :return:
        """
        # Bit ugly but we need to pass the embeddings as well.
        # Making a tuple will not work with the problem.get_cost function
        # print('input', input)

        return sample_many(
            lambda input: self._inner(*input),  # Need to unpack tuple into arguments
            lambda input, pi, tour, acc_late,acc_lengths,subs: self.problem.get_costs(input[0], self.obj, pi, tour, acc_late,acc_lengths,subs),  # Don't need embeddings as input to get_costs
            (input, self._init_embed(input)),  # Pack input with embeddings (additional input)
            batch_rep, iter_rep
        )
