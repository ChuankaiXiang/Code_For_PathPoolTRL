import os

from utils.data_utils import check_extension, save_dataset
import torch
import pickle
import argparse
import math
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
import random

def generate_hcvrp_data(dataset_size,
            cust_count,
            charge_station_count,
            depot_count,
            drone_count,
            drone_capa,
            drone_speed,
            drone_battery_capacity,
            drone_and_battery_weight,
            energy_consumption_env_factor,
            cust_loc_range,
            package_weight_range,
            horizon,
            service_time_range,
            tw_ratio,
            cust_tw_range,
            deg_of_dy,
            d_early_ratio,
            ):
    data = []
    path = 'data/transportation_nodes/node.csv'
    for seed in range(24601, 24602):
        file_path = r'F:\Joint PHD\New work\Project\PDP_Drone\PDPD_verion1\data\transportation_nodes\all_waybill_info_meituan_0322.csv'
        data_ = pd.read_csv(file_path)

        # Extract the specified columns and rows
        selected_data = data_.loc[1538:1959, ['sender_lng',
                                         'sender_lat',
                                         'recipient_lng',
                                         'recipient_lat',
                                         'estimate_arrived_time',
                                         'estimate_meal_prepare_time',
                                         'order_push_time']]

        # Filtering based on latitude as an example
        filtered_data = selected_data[
            (selected_data['sender_lat'] <= 46000000) & (selected_data['recipient_lat'] <= 46000000)
            & (selected_data['order_push_time'] != 0)
            & (selected_data['estimate_meal_prepare_time'] != 0)
            & (selected_data['estimate_arrived_time'] != 0)]




        pick_locs = filtered_data[['sender_lng', 'sender_lat']].values
        deliv_locs = filtered_data[['recipient_lng', 'recipient_lat']].values
        locs = np.concatenate((pick_locs, deliv_locs))


        aprs_ = filtered_data['order_push_time'].values
        aprs = np.concatenate((aprs_, aprs_))

        pick_rdys = filtered_data['estimate_meal_prepare_time'].values
        deliv_ldts = filtered_data['estimate_arrived_time'].values
        combined_times = np.concatenate((aprs, pick_rdys, deliv_ldts))
        # 计算最大值和最小值
        max_time = np.max(combined_times)
        min_time = np.min(combined_times)
        pick_ldts = np.full(pick_rdys.shape, max_time)
        deliv_rdys = np.full(deliv_ldts.shape, min_time)

        rdys = np.concatenate((pick_rdys, deliv_rdys))
        ldts = np.concatenate((pick_ldts, deliv_ldts))

        service_time = np.full(rdys.shape, 0.01)

        depot = np.array([[174537500,45900000],
                  [174565000,45875000],
                  [174575000,45840000],
                  [174587000,45881000],
                  [174595000,45851000]])



        charge_station =np.array( [[174536000,45886000],
                           [174565000,45862000],
                           [174565000,45805000],
                           [174587000,45870000],
                           [174620000,45874000],
                           [174575000,45900000]])

        #归一化
        scaler = MinMaxScaler()
        concatenated_locs = np.concatenate((locs, depot, charge_station), axis=0)
        concatenated_locs_lng = scaler.fit_transform(concatenated_locs[:, 0][:, None])
        concatenated_locs_lat = scaler.fit_transform(concatenated_locs[:, 1][:, None])

        concatenated_locs_ = np.concatenate((concatenated_locs_lng, concatenated_locs_lat), axis=1)
        locs = concatenated_locs_[:locs.shape[0]]
        depot = concatenated_locs_[locs.shape[0]:locs.shape[0]+depot.shape[0]]
        charge_station = concatenated_locs_[locs.shape[0]+depot.shape[0]:]

        aprs = scaler.fit_transform(aprs[:, None])
        rdys = scaler.fit_transform(rdys[:, None])
        ldts = scaler.fit_transform(ldts[:, None])

        locs = torch.tensor(locs, dtype=torch.float)[None,:]
        charge_station = torch.tensor(charge_station, dtype=torch.float)[None,:]
        depot = torch.tensor(depot, dtype=torch.float)[None,:]
        rdys = torch.tensor(rdys, dtype=torch.float)[None,:]
        ldts = torch.tensor(ldts, dtype=torch.float)[None,:]
        aprs = torch.tensor(aprs, dtype=torch.float)[None,:]
        service_time = torch.tensor(service_time, dtype=torch.float)[None,:,None]



        package_weight_P = torch.randint(*package_weight_range, (dataset_size,pick_locs.shape[0], 1), dtype=torch.float)
        package_weight_D = - package_weight_P
        package_weight = torch.cat((package_weight_P, package_weight_D), 1)
        drone_and_battery_weight_ = torch.tensor(drone_and_battery_weight, dtype=torch.float).expand(1)
        energy_consumption_env_factor = torch.tensor(energy_consumption_env_factor, dtype=torch.float).expand(1)

        package_weight /= drone_capa
        drone_and_battery_weight_ /= drone_capa





        drone_speed = torch.tensor(drone_speed, dtype=torch.float32).expand(1)
        drone_count = torch.tensor(drone_count, dtype=torch.float32).expand(1)

        thedata = list(zip(locs.tolist(),
                    charge_station.tolist(),
                    depot.tolist(),
                    drone_count.tolist(),
                    package_weight.tolist(),
                    drone_and_battery_weight_.tolist(),
                    energy_consumption_env_factor.tolist(),
                    service_time.tolist(),
                    rdys.tolist(),
                    ldts.tolist(),
                    aprs.tolist(),
                    drone_speed.tolist()
                           ))
        data.append(thedata)
    t = np.array(data)
    data = t.reshape(1, 12)

    return data


if __name__ == "__main__":

    # CUST_COUNT = 25
    # CUST_COUNT = 50
    CUST_COUNT = 140
    # CUST_COUNT = 160
    # CUST_COUNT = 70
    # CUST_COUNT = 5


    # Drone_count = 5
    # Drone_count = 10
    Drone_count = 50
    # Drone_count = 80
    # Drone_count = 20
    # Drone_count = 2


    Charge_station_count = 6
    Depot_count = 5
    Drone_CAPA = 150
    Drone_battery_capacity = 100  # 后面还得调整
    Drone_and_battery_weight = 10
    # Energy_consumption_env_factor = 0.5
    Energy_consumption_env_factor = 0.5
    Drone_SPEED = 5
    HORIZON = 480
    MIN_CUST_COUNT = None
    LOC_RANGE = (0, 101)
    Package_weigh_RANGE = (30, 40)
    DUR_RANGE = (10, 31)
    TW_RATIO = (0.25, 0.5, 0.75, 1.0)
    TW_RANGE = (30, 91)
    DEG_OF_DYN = 0.5
    APPEAR_EARLY_RATIO = (0.0, 0.5, 0.75, 1.0)

    parser = argparse.ArgumentParser()
    parser.add_argument("--filename", help="Filename of the dataset to create (ignores datadir)")
    parser.add_argument("--dataset_size", type=int, default=1, help="1/10 Size of the dataset")

    group = parser.add_argument_group("Data generation parameters")
    group.add_argument('--graph_size', "-n", type=int, default=CUST_COUNT)
    group.add_argument('--charge_station_count', "-l", type=int, default=Charge_station_count)
    group.add_argument('--depot_count', "-k", type=int, default=Depot_count)
    group.add_argument('--drone_count', "-m", type=int, default=Drone_count)
    group.add_argument("--drone_capa", type=int, default=Drone_CAPA)
    group.add_argument("--drone_battery_capacity", type=int, default=Drone_battery_capacity)
    group.add_argument("--drone_and_battery_weight", type=int, default=Drone_and_battery_weight)
    group.add_argument("--energy_consumption_env_factor", type=int, default=Energy_consumption_env_factor)
    group.add_argument("--drone_speed", type=int, default=Drone_SPEED)
    group.add_argument("--horizon", type=int, default=HORIZON)
    group.add_argument("--min_cust_count", type=int, default=MIN_CUST_COUNT)
    group.add_argument("--loc_range", type=int, nargs=2, default=LOC_RANGE)
    group.add_argument("--package_weight_range", type=int, nargs=2, default=Package_weigh_RANGE)
    group.add_argument("--service_time_range", type=int, nargs=2, default=DUR_RANGE)
    group.add_argument("--tw_ratio", type=float, nargs='*', default=TW_RATIO)
    group.add_argument("--tw_range", type=int, nargs=2, default=TW_RANGE)
    group.add_argument("--deg_of_dyna", type=float, nargs='*', default=DEG_OF_DYN)
    group.add_argument("--appear_early_ratio", type=float, nargs='*', default=APPEAR_EARLY_RATIO)

    opts = parser.parse_args()
    data_dir = 'data'
    problem = 'MVPDPC_cus_drone_realdata'
    datadir = os.path.join(data_dir, problem)
    os.makedirs(datadir, exist_ok=True)
    seed = 24610
    np.random.seed(seed)
    print(opts.dataset_size, opts.graph_size)
    filename = os.path.join(datadir, '50drone_instance_5.pkl'.format(problem, opts.drone_count, opts.graph_size,opts.charge_station_count,opts.depot_count, seed))

    dataset = generate_hcvrp_data(opts.dataset_size,
                                  opts.graph_size,
                                  opts.charge_station_count,
                                  opts.depot_count,
                                  opts.drone_count,
                                  opts.drone_capa,
                                  opts.drone_speed,
                                  opts.drone_battery_capacity,
                                  opts.drone_and_battery_weight,
                                  opts.energy_consumption_env_factor,
                                  opts.loc_range,
                                  opts.package_weight_range,
                                  opts.horizon,
                                  opts.service_time_range,
                                  opts.tw_ratio,
                                  opts.tw_range,
                                  opts.deg_of_dyna,
                                  opts.appear_early_ratio)
    print(dataset[0])
    save_dataset(dataset, filename)



