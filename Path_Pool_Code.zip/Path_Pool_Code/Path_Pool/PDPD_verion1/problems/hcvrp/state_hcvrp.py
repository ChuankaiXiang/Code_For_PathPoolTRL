import torch
from typing import NamedTuple
from utils.boolmask import mask_long2bool, mask_long_scatter



class StateHCVRP(NamedTuple):

    locs: torch.Tensor  # Depot + loc, [batch_size, graph_size+1, 2]
    package_weight: torch.Tensor
    service_time: torch.Tensor
    rdys: torch.Tensor
    ldts: torch.Tensor
    aprs: torch.Tensor
    drone: torch.Tensor  # numver of drones
    drone_rema_capa: torch.Tensor
    drone_remain_energy: torch.Tensor
    energy_consumption_factor: torch.Tensor
    drone_spes:torch.Tensor
    drone_cur_time: torch.Tensor
    drone_acc_late: torch.Tensor
    drone_hts: torch.Tensor
    drone_cts: torch.Tensor
    drone_path_context: torch.Tensor
    drone_prev_a: torch.Tensor
    drone_prev_prev_a: torch.Tensor
    drone_prev_3_a: torch.Tensor
    drone_prev_4_a: torch.Tensor
    drone_prev_5_a: torch.Tensor
    drone_prev_6_a: torch.Tensor
    drone_prev_7_a: torch.Tensor
    drone_prev_8_a: torch.Tensor
    drone_prev_9_a: torch.Tensor
    drone_prev_10_a: torch.Tensor
    drone_prev_11_a: torch.Tensor
    drone_prev_12_a: torch.Tensor
    drone_prev_13_a: torch.Tensor
    drone_prev_14_a: torch.Tensor
    drone_prev_15_a: torch.Tensor



    node_counts: torch.Tensor
    drone_masks : torch.Tensor
    ids: torch.Tensor  # Keeps track of original fixed data index of rows
    visited_: torch.Tensor  # Keeps track of nodes that have been visited
    lengths: torch.Tensor
    i: torch.Tensor  # Keeps track of step


    @property
    def visited(self):
        if self.visited_.dtype == torch.uint8:
            return self.visited_
        else:
            return self.visited_[:, None, :].expand(self.visited_.size(0), 1, -1).type(torch.ByteTensor)

    @property
    def dist(self):  # coords: []
        return (self.locs[:, :, None, :] - self.locs[:, None, :, :]).norm(p=2, dim=-1)

    def __getitem__(self, key):
        if torch.is_tensor(key) or isinstance(key, slice):  # If tensor, idx all tensors by this tensor:
            return self._replace(
                ids=self.ids[key],
                drone=self.drone[key],
                drone_rema_capa=self.drone_rema_capa[key],
                drone_remain_energy=self.drone_remain_energy[key],
                drone_cur_time=self.drone_cur_time[key],
                drone_prev_a=self.drone_prev_a[key],
                visited_=self.visited_[key],
                lengths=self.lengths[key],
                drone_masks=self.drone_masks[key],
                drone_acc_late = self.drone_acc_late,
            )
        return super(StateHCVRP, self).__getitem__(key)


    @staticmethod
    def initialize(input, visited_dtype=torch.uint8):


        loc = input['locs']
        charge_station = input['charge_station']
        depot = input['depot']
        package_weight = input['package_weight'].transpose(1, 2)
        service_time = input['service_time']
        rdys = input['rdys']
        ldts = input['ldts']
        aprs = input['aprs'].transpose(1, 2)
        drone_spes = input['drone_speed']
        batch_size, n_loc, _ = loc.size()  # n_loc = graph_size
        depot_num = input['depot'].size(1)
        charge_station_num = input['charge_station'].size(1)
        drone_count = input['drone_count'][0].int()
        energy_consumption_factor = torch.pow(input['drone_and_battery_weight'],3 / 2) * input['energy_consumption_env_factor']
        drone_prev_a = torch.zeros(batch_size, drone_count,dtype=torch.long, device=loc.device)
        drone_prev_prev_a = torch.zeros(batch_size, drone_count, dtype=torch.long, device=loc.device)
        drone_prev_3_a = torch.zeros(batch_size, drone_count, dtype=torch.long, device=loc.device)
        drone_prev_4_a = torch.zeros(batch_size, drone_count, dtype=torch.long, device=loc.device)
        drone_prev_5_a = torch.zeros(batch_size, drone_count, dtype=torch.long, device=loc.device)
        drone_prev_6_a = torch.zeros(batch_size, drone_count, dtype=torch.long, device=loc.device)
        drone_prev_7_a = torch.zeros(batch_size, drone_count, dtype=torch.long, device=loc.device)
        drone_prev_8_a = torch.zeros(batch_size, drone_count, dtype=torch.long, device=loc.device)
        drone_prev_9_a = torch.zeros(batch_size, drone_count, dtype=torch.long, device=loc.device)
        drone_prev_10_a = torch.zeros(batch_size, drone_count, dtype=torch.long, device=loc.device)
        drone_prev_11_a = torch.zeros(batch_size, drone_count, dtype=torch.long, device=loc.device)
        drone_prev_12_a = torch.zeros(batch_size, drone_count, dtype=torch.long, device=loc.device)
        drone_prev_13_a = torch.zeros(batch_size, drone_count, dtype=torch.long, device=loc.device)
        drone_prev_14_a = torch.zeros(batch_size, drone_count, dtype=torch.long, device=loc.device)
        drone_prev_15_a = torch.zeros(batch_size, drone_count, dtype=torch.long, device=loc.device)



        node_counts = torch.ones(batch_size, drone_count,1,dtype=torch.long, device=loc.device)

        return StateHCVRP(
            locs=torch.cat((depot,charge_station, loc), -2),
            package_weight = torch.cat((torch.zeros(package_weight.size(0), package_weight.size(1), depot_num+charge_station_num, device=package_weight.device),package_weight),-1),
            service_time = torch.cat((torch.zeros(service_time.size(0), depot_num+charge_station_num, service_time.size(2),device=service_time.device),service_time),1),
            rdys = torch.cat((torch.zeros(rdys.size(0), depot_num+charge_station_num, rdys.size(2), device=rdys.device), rdys), 1),
            ldts = torch.cat((torch.ones(ldts.size(0), depot_num+charge_station_num, ldts.size(2), device=ldts.device), ldts), 1),
            aprs=torch.cat((torch.zeros(aprs.size(0), package_weight.size(1), depot_num+charge_station_num, device=aprs.device), aprs), -1),
            # 飞机剩余容量
            drone_rema_capa = 1*torch.ones(batch_size, drone_count, 1, device=loc.device),
            # 飞机剩余能量
            drone_remain_energy = torch.ones(batch_size, drone_count, 1, device=loc.device),
            # 飞机的能力消耗并非线性，其能量消耗与多方面有关，将动态的因子保存在这里
            energy_consumption_factor = energy_consumption_factor[:,None,None].expand( batch_size,drone_count,1),
            # 飞机速度
            drone_spes = drone_spes,
            # 飞机当前时间
            drone_cur_time= torch.zeros(batch_size, drone_count, 1, device=loc.device),
            # 飞机延误时间
            drone_acc_late= torch.zeros(batch_size, drone_count, 1, device=loc.device),
            # pointer_network的输入
            drone_hts = torch.zeros(batch_size,drone_count,128,device=loc.device),
            # pointer_network的输入
            drone_cts=torch.zeros(batch_size, drone_count, 128, device=loc.device),
            # path_context
            drone_path_context=torch.zeros(batch_size, drone_count, 128, device=loc.device),
            ids=torch.arange(batch_size, dtype=torch.int64, device=loc.device)[:, None],
            drone=torch.arange(drone_count, dtype=torch.int64, device=loc.device)[:, None],
            drone_prev_a = drone_prev_a,
            drone_prev_prev_a = drone_prev_prev_a,
            drone_prev_3_a = drone_prev_3_a,
            drone_prev_4_a=drone_prev_4_a,
            drone_prev_5_a = drone_prev_5_a,
            drone_prev_6_a = drone_prev_6_a,
            drone_prev_7_a = drone_prev_7_a,
            drone_prev_8_a = drone_prev_8_a,
            drone_prev_9_a = drone_prev_9_a,
            drone_prev_10_a = drone_prev_10_a,
            drone_prev_11_a = drone_prev_11_a,
            drone_prev_12_a = drone_prev_12_a,
            drone_prev_13_a = drone_prev_13_a,
            drone_prev_14_a = drone_prev_14_a,
            drone_prev_15_a = drone_prev_15_a,





            # 飞机已访问节点的个数
            node_counts = node_counts,
            # 已访问过的节点
            visited_= torch.cat([torch.ones(batch_size, 1, depot_num + charge_station_num ,dtype=torch.uint8, device=loc.device)
                      ,torch.zeros(batch_size, 1, n_loc,dtype=torch.uint8, device=loc.device)
                      ],2 ),
            # 所有路径的长度
            lengths=torch.zeros(batch_size, drone_count, device=loc.device),
            i=torch.zeros(1, dtype=torch.int64, device=loc.device),  # Vector with length num_steps
            # 用于计算mask
            drone_masks = torch.cat([torch.ones(batch_size, drone_count, n_loc // 2 + depot_num + charge_station_num, dtype=torch.uint8, device=loc.device),
            torch.zeros(batch_size, drone_count, n_loc // 2, dtype=torch.uint8, device=loc.device)], dim=-1).expand(batch_size,drone_count, n_loc+depot_num+charge_station_num) #这里n_loc 没有包含depot点 512*3*n_loc
        )



    def update (self, selected, drone, non_cus_index, need_charge, depot_num, charge_station_num,drone_and_battery_weight,energy_consumption_env_factor):

        assert self.i.size(0) == 1, "Can only update if state represents single step"




        #更新单个车的delivery索引
        drone_count = selected.size(1)
        n_loc = self.drone_masks.size(-1) - (depot_num + charge_station_num) # number of customers
        batch_size, _ = selected.size()

        new_delivery = (selected[torch.arange(selected.size(0)), drone] + n_loc // 2) % (n_loc+depot_num + charge_station_num)  # the pair node of selected node(512*1)
        tt = selected[torch.arange(selected.size(0)), drone]

        prev_a = self.drone_prev_a.clone().cuda()
        prev_prev_a = self.drone_prev_prev_a.clone().cuda()
        prev_3_a = self.drone_prev_3_a.clone().cuda()
        prev_4_a = self.drone_prev_4_a.clone().cuda()
        prev_5_a = self.drone_prev_5_a.clone().cuda()
        prev_6_a = self.drone_prev_6_a.clone().cuda()
        prev_7_a = self.drone_prev_7_a.clone().cuda()
        prev_8_a = self.drone_prev_8_a.clone().cuda()
        prev_9_a = self.drone_prev_9_a.clone().cuda()
        prev_10_a = self.drone_prev_10_a.clone().cuda()
        prev_11_a = self.drone_prev_11_a.clone().cuda()
        prev_12_a = self.drone_prev_12_a.clone().cuda()
        prev_13_a = self.drone_prev_13_a.clone().cuda()
        prev_14_a = self.drone_prev_14_a.clone().cuda()
        prev_15_a = self.drone_prev_15_a.clone().cuda()



        drone_prev_coord = self.locs.gather(1,prev_a[:, :, None].expand(prev_a.size(0), drone_count, self.locs.size(-1)))

        prev_15_a = prev_14_a
        prev_14_a = prev_13_a
        prev_13_a = prev_12_a
        prev_12_a = prev_11_a
        prev_11_a = prev_10_a
        prev_10_a = prev_9_a
        prev_9_a = prev_8_a
        prev_8_a = prev_7_a
        prev_7_a = prev_6_a
        prev_6_a = prev_5_a
        prev_5_a = prev_4_a
        prev_4_a = prev_3_a
        prev_3_a = prev_prev_a
        prev_prev_a = prev_a
        prev_a = selected



        #更新车辆时间和行驶路程
        cur_coord = self.locs.gather(1,selected[:, :, None].expand(selected.size(0), drone_count, self.locs.size(-1)))
        sel_cur_coord = cur_coord.gather(1, drone[:,None,None].expand(cur_coord.size(0),1 , cur_coord.size(2)))
        sel_drone_prev_cur_coord = drone_prev_coord.gather(1, drone[:,None,None].expand(drone_prev_coord.size(0),1 , drone_prev_coord.size(2)))
        sel_cur_tra_lengths = (sel_cur_coord- sel_drone_prev_cur_coord).norm(p=2, dim=-1)

        lengths = self.lengths.clone().cuda()
        sel_drone_lengths = lengths.gather(1, drone[:,None].expand(lengths.size(0), 1))
        acc_sel_drone_lenghts = sel_drone_lengths + sel_cur_tra_lengths

        ####这里更新累计的行驶路程####
        acc_lengths = lengths.scatter(1, drone[:, None], acc_sel_drone_lenghts)


        sel_drone_trav_time = sel_cur_tra_lengths/self.drone_spes[:,None]
        sel_drone_cur_time = self.drone_cur_time.gather(1, drone[:,None,None].expand(self.drone_cur_time.size(0),self.drone_cur_time.size(2) , 1))

        cur_loc_rdys = self.rdys.gather(1,selected[:, :, None].expand(selected.size(0), drone_count, self.rdys.size(-1)))
        sel_cur_loc_rdys = cur_loc_rdys.gather(1, drone[:,None,None].expand(cur_loc_rdys.size(0),cur_loc_rdys.size(2) , 1))

        sel_drone_arv_time = torch.max(sel_drone_cur_time + sel_drone_trav_time[:,:,None], sel_cur_loc_rdys)

        cur_loc_ldts = self.ldts.gather(1,selected[:, :, None].expand(selected.size(0), drone_count, self.ldts.size(-1)))
        sel_cur_loc_ldts = cur_loc_ldts.gather(1, drone[:,None,None].expand(cur_loc_ldts.size(0),cur_loc_ldts.size(2) , 1))


        sel_drone_late = (sel_drone_arv_time - sel_cur_loc_ldts).clamp_(min = 0)
        ###需要把没有乘客到达的车辆的这轮的迟到时间归零###
        sel_drone_late[non_cus_index] = 0

        sel_drone_acc_late = self.drone_acc_late.gather(1, drone[:,None,None].expand(self.drone_acc_late.size(0),self.drone_acc_late.size(2) , 1))
        sel_acc_late = sel_drone_late + sel_drone_acc_late


        drone_acc_late = self.drone_acc_late.clone().cuda()
        acc_late = drone_acc_late.scatter(1, drone[:,None,None], sel_acc_late)

        service_time = self.service_time.gather(1,selected[:, :, None].expand(selected.size(0), drone_count, self.service_time.size(-1)))
        sel_service_time = service_time.gather(1, drone[:,None,None].expand(service_time.size(0),service_time.size(2) , 1))

        sel_cur_time = sel_drone_arv_time + sel_service_time


        #####如果此时选择出的车辆的无路可走，那么该车存在两种状态，第一种状态是所有的任务都完成了，此时增加车辆的系统时间对车辆的时间延迟无影响，第二种状态是存在任务尚未到达，即车辆当前的系统时间未到达
        #####某些任务的出现时间，所以这些任务的仍被隐藏的，此时我们将该车辆的系统时间增加0.1,
        sel_cur_time[non_cus_index]= sel_cur_time[non_cus_index] + 0.1

        cur_time = self.drone_cur_time.clone().cuda()
        cur_time = cur_time.scatter(1, drone[:,None,None], sel_cur_time)


        cur_drone_rema_capa = self.drone_rema_capa.gather(1, drone[:,None,None].expand(self.drone_rema_capa.size(0),  self.drone_rema_capa.size(2),1))
        drone_arri = selected[:,:,None].gather(1, drone[:,None,None].expand(selected.size(0),  1,1))
        drone_arri_package_weight= self.package_weight.transpose(1,2).gather(1, drone_arri.expand(selected.size(0), 1, 1))
        cur_drone_rema_capa -= drone_arri_package_weight
        drone_rema_capa =self.drone_rema_capa.clone().cuda()
        drone_rema_capa = drone_rema_capa.scatter(1, drone[:,None,None], cur_drone_rema_capa)

        cur_drone_acc_load = 1 - cur_drone_rema_capa
        t = torch.pow(drone_and_battery_weight + cur_drone_acc_load.squeeze(), 3/2)
        cur_energy_consumption_factor = torch.pow(drone_and_battery_weight + cur_drone_acc_load.squeeze(), 3/2)*energy_consumption_env_factor
        energy_consumption_factor = self.energy_consumption_factor.clone().cuda()
        energy_consumption_factor = energy_consumption_factor.scatter(1, drone[:,None,None], cur_energy_consumption_factor[:,None,None])

        cur_drone_remain_energy = self.drone_remain_energy.gather(1, drone[:,None,None].expand(self.drone_remain_energy.size(0),  self.drone_remain_energy.size(2),1))
        # cur_drone_remain_energy -= sel_cur_tra_lengths[:,:,None]*cur_energy_consumption_factor[:,None,None]
        cur_drone_remain_energy -= sel_cur_tra_lengths[:, :, None] * 0.3
        cur_drone_remain_energy[non_cus_index] = 1.
        cur_drone_remain_energy[need_charge] = 1.
        drone_remain_energy =self.drone_remain_energy.clone().cuda()
        drone_remain_energy = drone_remain_energy.scatter(1, drone[:,None,None], cur_drone_remain_energy)

        if self.visited_.dtype == torch.uint8:
            visited_ = self.visited_.scatter(-1, selected[torch.arange(batch_size), drone][:, None, None].expand_as(self.visited_[:, :, 0:1]), 1) # 512*1*LOC

            prev_delivery = self.drone_masks.clone().cuda()
            now_delivery = prev_delivery.gather(1, drone[:,None,None].expand(prev_delivery.size(0), 1, prev_delivery.size(2))) # 512*1*n_loc


            now_delivery = now_delivery.scatter(-1, new_delivery[:, None, None], 1).squeeze()
            delivery = prev_delivery
            delivery = delivery.scatter(1, drone[:,None,None].expand(prev_delivery.size(0), 1, prev_delivery.size(2)),now_delivery[:,None,:].expand(prev_delivery.size(0),drone_count,prev_delivery.size(2)))

        else:
            visited_ = mask_long_scatter(self.visited_, selected[torch.arange(batch_size), drone])


        return self._replace(
            drone_prev_15_a=prev_15_a,
            drone_prev_14_a=prev_14_a,
            drone_prev_13_a=prev_13_a,
            drone_prev_12_a=prev_12_a,
            drone_prev_11_a=prev_11_a,
            drone_prev_10_a=prev_10_a,
            drone_prev_9_a=prev_9_a,
            drone_prev_8_a=prev_8_a,
            drone_prev_7_a=prev_7_a,
            drone_prev_6_a=prev_6_a,
            drone_prev_5_a=prev_5_a,
            drone_prev_4_a=prev_4_a,
            drone_prev_3_a=prev_3_a,
            drone_prev_prev_a = prev_prev_a,
            drone_prev_a=prev_a,
            visited_=visited_, lengths=acc_lengths,  i=self.i + 1, drone_masks=delivery, drone_rema_capa=drone_rema_capa,drone_cur_time=cur_time,
            drone_acc_late=acc_late, drone_remain_energy= drone_remain_energy, energy_consumption_factor= energy_consumption_factor
        )

    def all_finished(self):

        # t = self.visited.sum(-1)

        return self.visited.all()

    def get_finished(self):
        return self.visited.sum(-1) == self.visited.size(-1)

    def _init_h_c_t(self,enc_h_t, enc_c_t):
        drone_hts=self.drone_hts.clone().cuda()
        drone_cts = self.drone_cts.clone().cuda()
        drone_count = drone_hts.size(1)
        for i in range(drone_count):
            drone_hts[:,i,:] = enc_h_t
            drone_cts[:, i, :] = enc_c_t

        return self._replace(drone_hts=drone_hts,drone_cts=drone_cts)

    def get_h_c_t(self,drone):
        drone_hts = self.drone_hts.clone().cuda()
        drone_cts = self.drone_cts.clone().cuda()

        drone_ht = drone_hts.gather(1,drone[:, None, None].expand(drone_hts.size(0), 1, drone_hts.size(2))).squeeze()
        drone_ct = drone_cts.gather(1,drone[:, None, None].expand(drone_cts.size(0), 1, drone_cts.size(2))).squeeze()
        return drone_ht,drone_ct

    def update_hidden(self,drone,hidden):
        drone_hts = self.drone_hts.clone().cuda()
        drone_cts = self.drone_cts.clone().cuda()
        ht= hidden[0]
        ct = hidden[1]
        up_drone_hts = drone_hts.scatter(1, drone[:, None, None].expand(drone_hts.size(0),1,drone_hts.size(-1)),ht[:,None,:])

        up_drone_cts = drone_cts.scatter(1, drone[:, None, None].expand(drone_cts.size(0),1,drone_cts.size(-1)), ct[:, None, :])

        return  self._replace(drone_hts=up_drone_hts,drone_cts=up_drone_cts)

    def get_path_context(self, drone):
        drone_path_context = self.drone_path_context.clone().cuda()
        path_context = drone_path_context.gather(1, drone[:, None, None].expand(drone_path_context.size(0), 1, drone_path_context.size(2))).squeeze()
        return path_context



    def update_path_context(self,selected,drone,embedding):
        drone_path_contexts = self.drone_path_context.clone().cuda()
        selected_drone_path_context = drone_path_contexts.gather(1, drone[:, None, None].expand(drone_path_contexts.size(0), 1, drone_path_contexts.size(2)))

        drone_next_visit = selected[torch.arange(selected.size(0)), drone]
        drone_next_visit_embedding = torch.gather(embedding, 1, drone_next_visit[:, None,None].expand(drone_next_visit.size(0), 1,embedding.size(2)))

        updated_drone_path_context = torch.cat([selected_drone_path_context, drone_next_visit_embedding], dim=1).mean(1)

        up_drone_path_contexts = drone_path_contexts.scatter(1, drone[:, None, None].expand(drone_path_contexts.size(0), 1, drone_path_contexts.size(2)),updated_drone_path_context[:,None,:])

        return self._replace(drone_path_context=up_drone_path_contexts)




    def get_path_context_1(self, drone, embedding):
        drone_prev_a = self.drone_prev_a.clone().cuda()
        drone_prev_visit = drone_prev_a[torch.arange(drone_prev_a.size(0)), drone]
        drone_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_visit[:, None, None].expand(drone_prev_visit.size(0), 1, embedding.size(2)))

        return drone_prev_visit_embedding.squeeze()


    def get_path_context_2(self, drone, embedding):

        drone_prev_a = self.drone_prev_a.clone().cuda()
        drone_prev_visit = drone_prev_a[torch.arange(drone_prev_a.size(0)), drone]
        drone_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_visit[:, None, None].expand(drone_prev_visit.size(0), 1, embedding.size(2)))

        drone_prev_prev_a = self.drone_prev_prev_a.clone().cuda()
        drone_prev_prev_visit = drone_prev_prev_a[torch.arange(drone_prev_prev_a.size(0)), drone]
        drone_prev_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_prev_visit[:, None, None].expand(drone_prev_prev_visit.size(0), 1, embedding.size(2)))

        drone_path_context = torch.cat([drone_prev_visit_embedding, drone_prev_prev_visit_embedding], dim=1).mean(1)

        return drone_path_context.squeeze()



    def get_path_context_3(self, drone, embedding):



        drone_prev_3_a = self.drone_prev_3_a.clone().cuda()
        drone_prev_3_visit = drone_prev_3_a[torch.arange(drone_prev_3_a.size(0)), drone]
        drone_prev_3_visit_embedding = torch.gather(embedding, 1, drone_prev_3_visit[:, None, None].expand(drone_prev_3_visit.size(0), 1, embedding.size(2)))

        drone_prev_prev_a = self.drone_prev_prev_a.clone().cuda()
        drone_prev_prev_visit = drone_prev_prev_a[torch.arange(drone_prev_prev_a.size(0)), drone]
        drone_prev_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_prev_visit[:, None, None].expand(drone_prev_prev_visit.size(0), 1, embedding.size(2)))

        drone_path_context_1 = torch.cat([drone_prev_3_visit_embedding, drone_prev_prev_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_a = self.drone_prev_a.clone().cuda()
        drone_prev_visit = drone_prev_a[torch.arange(drone_prev_a.size(0)), drone]
        drone_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_visit[:, None, None].expand(drone_prev_visit.size(0), 1, embedding.size(2)))


        drone_path_context_2 = torch.cat([drone_path_context_1,drone_prev_visit_embedding], dim=1).mean(1)

        return drone_path_context_2.squeeze()
    

    def get_path_context_4(self, drone, embedding):
       
        drone_prev_4_a = self.drone_prev_4_a.clone().cuda()
        drone_prev_4_visit = drone_prev_4_a[torch.arange(drone_prev_4_a.size(0)), drone]
        drone_prev_4_visit_embedding = torch.gather(
            embedding, 1, drone_prev_4_visit[:, None, None].expand(drone_prev_4_visit.size(0), 1, embedding.size(2))
        )    
       
        drone_prev_3_a = self.drone_prev_3_a.clone().cuda()
        drone_prev_3_visit = drone_prev_3_a[torch.arange(drone_prev_3_a.size(0)), drone]
        drone_prev_3_visit_embedding = torch.gather(embedding, 1, drone_prev_3_visit[:, None, None].expand(drone_prev_3_visit.size(0), 1, embedding.size(2)))

        drone_path_context_1 = torch.cat([drone_prev_4_visit_embedding, drone_prev_3_visit_embedding], dim=1).mean(1)[:,None,:]
       
        drone_prev_prev_a = self.drone_prev_prev_a.clone().cuda()
        drone_prev_prev_visit = drone_prev_prev_a[torch.arange(drone_prev_prev_a.size(0)), drone]
        drone_prev_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_prev_visit[:, None, None].expand(drone_prev_prev_visit.size(0), 1, embedding.size(2)))

        drone_path_context_2 = torch.cat([drone_path_context_1,drone_prev_prev_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_a = self.drone_prev_a.clone().cuda()
        drone_prev_visit = drone_prev_a[torch.arange(drone_prev_a.size(0)), drone]
        drone_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_visit[:, None, None].expand(drone_prev_visit.size(0), 1, embedding.size(2)))


        drone_path_context_3 = torch.cat([drone_path_context_2,drone_prev_visit_embedding], dim=1).mean(1)


        return drone_path_context_3.squeeze()


    def get_path_context_5(self, drone, embedding):


        drone_prev_5_a = self.drone_prev_5_a.clone().cuda()
        drone_prev_5_visit = drone_prev_5_a[torch.arange(drone_prev_5_a.size(0)), drone]
        drone_prev_5_visit_embedding = torch.gather(
            embedding, 1, drone_prev_5_visit[:, None, None].expand(drone_prev_5_visit.size(0), 1, embedding.size(2))
        )


        drone_prev_4_a = self.drone_prev_4_a.clone().cuda()
        drone_prev_4_visit = drone_prev_4_a[torch.arange(drone_prev_4_a.size(0)), drone]
        drone_prev_4_visit_embedding = torch.gather(
            embedding, 1, drone_prev_4_visit[:, None, None].expand(drone_prev_4_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_1 = torch.cat([drone_prev_5_visit_embedding, drone_prev_4_visit_embedding], dim=1).mean(1)[:,None,:]


        drone_prev_3_a = self.drone_prev_3_a.clone().cuda()
        drone_prev_3_visit = drone_prev_3_a[torch.arange(drone_prev_3_a.size(0)), drone]
        drone_prev_3_visit_embedding = torch.gather(embedding, 1, drone_prev_3_visit[:, None, None].expand(drone_prev_3_visit.size(0), 1, embedding.size(2)))

        drone_path_context_2 = torch.cat([drone_path_context_1,drone_prev_3_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_prev_a = self.drone_prev_prev_a.clone().cuda()
        drone_prev_prev_visit = drone_prev_prev_a[torch.arange(drone_prev_prev_a.size(0)), drone]
        drone_prev_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_prev_visit[:, None, None].expand(drone_prev_prev_visit.size(0), 1, embedding.size(2)))

        drone_path_context_3 = torch.cat([drone_path_context_2,drone_prev_prev_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_a = self.drone_prev_a.clone().cuda()
        drone_prev_visit = drone_prev_a[torch.arange(drone_prev_a.size(0)), drone]
        drone_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_visit[:, None, None].expand(drone_prev_visit.size(0), 1, embedding.size(2)))

        drone_path_context_4 = torch.cat([drone_path_context_3,drone_prev_visit_embedding], dim=1).mean(1)


        return drone_path_context_4.squeeze()


    def get_path_context_6(self, drone, embedding):
       
        drone_prev_6_a = self.drone_prev_6_a.clone().cuda()
        drone_prev_6_visit = drone_prev_6_a[torch.arange(drone_prev_6_a.size(0)), drone]
        drone_prev_6_visit_embedding = torch.gather(
            embedding, 1, drone_prev_6_visit[:, None, None].expand(drone_prev_6_visit.size(0), 1, embedding.size(2))
        )   

        drone_prev_5_a = self.drone_prev_5_a.clone().cuda()
        drone_prev_5_visit = drone_prev_5_a[torch.arange(drone_prev_5_a.size(0)), drone]
        drone_prev_5_visit_embedding = torch.gather(
            embedding, 1, drone_prev_5_visit[:, None, None].expand(drone_prev_5_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_1 = torch.cat([drone_prev_6_visit_embedding, drone_prev_5_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_4_a = self.drone_prev_4_a.clone().cuda()
        drone_prev_4_visit = drone_prev_4_a[torch.arange(drone_prev_4_a.size(0)), drone]
        drone_prev_4_visit_embedding = torch.gather(
            embedding, 1, drone_prev_4_visit[:, None, None].expand(drone_prev_4_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_2 = torch.cat([drone_path_context_1,drone_prev_4_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_3_a = self.drone_prev_3_a.clone().cuda()
        drone_prev_3_visit = drone_prev_3_a[torch.arange(drone_prev_3_a.size(0)), drone]
        drone_prev_3_visit_embedding = torch.gather(embedding, 1, drone_prev_3_visit[:, None, None].expand(drone_prev_3_visit.size(0), 1, embedding.size(2)))

        drone_path_context_3 = torch.cat([drone_path_context_2,drone_prev_3_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_prev_a = self.drone_prev_prev_a.clone().cuda()
        drone_prev_prev_visit = drone_prev_prev_a[torch.arange(drone_prev_prev_a.size(0)), drone]
        drone_prev_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_prev_visit[:, None, None].expand(drone_prev_prev_visit.size(0), 1, embedding.size(2)))

        drone_path_context_4 = torch.cat([drone_path_context_3,drone_prev_prev_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_a = self.drone_prev_a.clone().cuda()
        drone_prev_visit = drone_prev_a[torch.arange(drone_prev_a.size(0)), drone]
        drone_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_visit[:, None, None].expand(drone_prev_visit.size(0), 1, embedding.size(2)))

        drone_path_context_5 = torch.cat([drone_path_context_4,drone_prev_visit_embedding], dim=1).mean(1)


        return drone_path_context_5.squeeze()
    
    def get_path_context_7(self, drone, embedding):
    
        drone_prev_7_a = self.drone_prev_7_a.clone().cuda()
        drone_prev_7_visit = drone_prev_7_a[torch.arange(drone_prev_7_a.size(0)), drone]
        drone_prev_7_visit_embedding = torch.gather(
            embedding, 1, drone_prev_7_visit[:, None, None].expand(drone_prev_7_visit.size(0), 1, embedding.size(2))
        )

        drone_prev_6_a = self.drone_prev_6_a.clone().cuda()
        drone_prev_6_visit = drone_prev_6_a[torch.arange(drone_prev_6_a.size(0)), drone]
        drone_prev_6_visit_embedding = torch.gather(
            embedding, 1, drone_prev_6_visit[:, None, None].expand(drone_prev_6_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_1 = torch.cat([drone_prev_7_visit_embedding, drone_prev_6_visit_embedding], dim=1).mean(1)[:,None,:]   

        drone_prev_5_a = self.drone_prev_5_a.clone().cuda()
        drone_prev_5_visit = drone_prev_5_a[torch.arange(drone_prev_5_a.size(0)), drone]
        drone_prev_5_visit_embedding = torch.gather(
            embedding, 1, drone_prev_5_visit[:, None, None].expand(drone_prev_5_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_2 = torch.cat([drone_path_context_1,drone_prev_5_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_4_a = self.drone_prev_4_a.clone().cuda()
        drone_prev_4_visit = drone_prev_4_a[torch.arange(drone_prev_4_a.size(0)), drone]
        drone_prev_4_visit_embedding = torch.gather(
            embedding, 1, drone_prev_4_visit[:, None, None].expand(drone_prev_4_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_3 = torch.cat([drone_path_context_2,drone_prev_4_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_3_a = self.drone_prev_3_a.clone().cuda()
        drone_prev_3_visit = drone_prev_3_a[torch.arange(drone_prev_3_a.size(0)), drone]
        drone_prev_3_visit_embedding = torch.gather(embedding, 1, drone_prev_3_visit[:, None, None].expand(drone_prev_3_visit.size(0), 1, embedding.size(2)))

        drone_path_context_4 = torch.cat([drone_path_context_3,drone_prev_3_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_prev_a = self.drone_prev_prev_a.clone().cuda()
        drone_prev_prev_visit = drone_prev_prev_a[torch.arange(drone_prev_prev_a.size(0)), drone]
        drone_prev_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_prev_visit[:, None, None].expand(drone_prev_prev_visit.size(0), 1, embedding.size(2)))

        drone_path_context_5 = torch.cat([drone_path_context_4,drone_prev_prev_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_a = self.drone_prev_a.clone().cuda()
        drone_prev_visit = drone_prev_a[torch.arange(drone_prev_a.size(0)), drone]
        drone_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_visit[:, None, None].expand(drone_prev_visit.size(0), 1, embedding.size(2)))


        drone_path_context_6 = torch.cat([drone_path_context_5,drone_prev_visit_embedding], dim=1).mean(1)

        return drone_path_context_6.squeeze()

    def get_path_context_8(self, drone, embedding):
    
        drone_prev_8_a = self.drone_prev_8_a.clone().cuda()
        drone_prev_8_visit = drone_prev_8_a[torch.arange(drone_prev_8_a.size(0)), drone]
        drone_prev_8_visit_embedding = torch.gather(
            embedding, 1, drone_prev_8_visit[:, None, None].expand(drone_prev_8_visit.size(0), 1, embedding.size(2))
        )


        drone_prev_7_a = self.drone_prev_7_a.clone().cuda()
        drone_prev_7_visit = drone_prev_7_a[torch.arange(drone_prev_7_a.size(0)), drone]
        drone_prev_7_visit_embedding = torch.gather(
            embedding, 1, drone_prev_7_visit[:, None, None].expand(drone_prev_7_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_1 = torch.cat([drone_prev_8_visit_embedding, drone_prev_7_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_6_a = self.drone_prev_6_a.clone().cuda()
        drone_prev_6_visit = drone_prev_6_a[torch.arange(drone_prev_6_a.size(0)), drone]
        drone_prev_6_visit_embedding = torch.gather(
            embedding, 1, drone_prev_6_visit[:, None, None].expand(drone_prev_6_visit.size(0), 1, embedding.size(2))
        )


        drone_path_context_2 = torch.cat([drone_path_context_1,drone_prev_6_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_5_a = self.drone_prev_5_a.clone().cuda()
        drone_prev_5_visit = drone_prev_5_a[torch.arange(drone_prev_5_a.size(0)), drone]
        drone_prev_5_visit_embedding = torch.gather(
            embedding, 1, drone_prev_5_visit[:, None, None].expand(drone_prev_5_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_3 = torch.cat([drone_path_context_2,drone_prev_5_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_4_a = self.drone_prev_4_a.clone().cuda()
        drone_prev_4_visit = drone_prev_4_a[torch.arange(drone_prev_4_a.size(0)), drone]
        drone_prev_4_visit_embedding = torch.gather(
            embedding, 1, drone_prev_4_visit[:, None, None].expand(drone_prev_4_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_4 = torch.cat([drone_path_context_3,drone_prev_4_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_3_a = self.drone_prev_3_a.clone().cuda()
        drone_prev_3_visit = drone_prev_3_a[torch.arange(drone_prev_3_a.size(0)), drone]
        drone_prev_3_visit_embedding = torch.gather(embedding, 1, drone_prev_3_visit[:, None, None].expand(drone_prev_3_visit.size(0), 1, embedding.size(2)))

        drone_path_context_5 = torch.cat([drone_path_context_4,drone_prev_3_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_prev_a = self.drone_prev_prev_a.clone().cuda()
        drone_prev_prev_visit = drone_prev_prev_a[torch.arange(drone_prev_prev_a.size(0)), drone]
        drone_prev_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_prev_visit[:, None, None].expand(drone_prev_prev_visit.size(0), 1, embedding.size(2)))

        drone_path_context_6 = torch.cat([drone_path_context_5,drone_prev_prev_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_a = self.drone_prev_a.clone().cuda()
        drone_prev_visit = drone_prev_a[torch.arange(drone_prev_a.size(0)), drone]
        drone_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_visit[:, None, None].expand(drone_prev_visit.size(0), 1, embedding.size(2)))


        drone_path_context_7 = torch.cat([drone_path_context_6,drone_prev_visit_embedding], dim=1).mean(1)

        return drone_path_context_7.squeeze()


    def get_path_context_9(self, drone, embedding):
    
        
        drone_prev_9_a = self.drone_prev_9_a.clone().cuda()
        drone_prev_9_visit = drone_prev_9_a[torch.arange(drone_prev_9_a.size(0)), drone]
        drone_prev_9_visit_embedding = torch.gather(
            embedding, 1, drone_prev_9_visit[:, None, None].expand(drone_prev_9_visit.size(0), 1, embedding.size(2))
        )
        
        drone_prev_8_a = self.drone_prev_8_a.clone().cuda()
        drone_prev_8_visit = drone_prev_8_a[torch.arange(drone_prev_8_a.size(0)), drone]
        drone_prev_8_visit_embedding = torch.gather(
            embedding, 1, drone_prev_8_visit[:, None, None].expand(drone_prev_8_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_1 = torch.cat([drone_prev_9_visit_embedding, drone_prev_8_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_7_a = self.drone_prev_7_a.clone().cuda()
        drone_prev_7_visit = drone_prev_7_a[torch.arange(drone_prev_7_a.size(0)), drone]
        drone_prev_7_visit_embedding = torch.gather(
            embedding, 1, drone_prev_7_visit[:, None, None].expand(drone_prev_7_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_2 = torch.cat([drone_path_context_1,drone_prev_7_visit_embedding], dim=1).mean(1)[:,None,:]


        drone_prev_6_a = self.drone_prev_6_a.clone().cuda()
        drone_prev_6_visit = drone_prev_6_a[torch.arange(drone_prev_6_a.size(0)), drone]
        drone_prev_6_visit_embedding = torch.gather(
            embedding, 1, drone_prev_6_visit[:, None, None].expand(drone_prev_6_visit.size(0), 1, embedding.size(2))
        )


        drone_path_context_3 = torch.cat([drone_path_context_2,drone_prev_6_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_5_a = self.drone_prev_5_a.clone().cuda()
        drone_prev_5_visit = drone_prev_5_a[torch.arange(drone_prev_5_a.size(0)), drone]
        drone_prev_5_visit_embedding = torch.gather(
            embedding, 1, drone_prev_5_visit[:, None, None].expand(drone_prev_5_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_4 = torch.cat([drone_path_context_3,drone_prev_5_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_4_a = self.drone_prev_4_a.clone().cuda()
        drone_prev_4_visit = drone_prev_4_a[torch.arange(drone_prev_4_a.size(0)), drone]
        drone_prev_4_visit_embedding = torch.gather(
            embedding, 1, drone_prev_4_visit[:, None, None].expand(drone_prev_4_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_5 = torch.cat([drone_path_context_4,drone_prev_4_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_3_a = self.drone_prev_3_a.clone().cuda()
        drone_prev_3_visit = drone_prev_3_a[torch.arange(drone_prev_3_a.size(0)), drone]
        drone_prev_3_visit_embedding = torch.gather(embedding, 1, drone_prev_3_visit[:, None, None].expand(drone_prev_3_visit.size(0), 1, embedding.size(2)))

        drone_path_context_6 = torch.cat([drone_path_context_5,drone_prev_3_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_prev_a = self.drone_prev_prev_a.clone().cuda()
        drone_prev_prev_visit = drone_prev_prev_a[torch.arange(drone_prev_prev_a.size(0)), drone]
        drone_prev_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_prev_visit[:, None, None].expand(drone_prev_prev_visit.size(0), 1, embedding.size(2)))

        drone_path_context_7 = torch.cat([drone_path_context_6,drone_prev_prev_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_a = self.drone_prev_a.clone().cuda()
        drone_prev_visit = drone_prev_a[torch.arange(drone_prev_a.size(0)), drone]
        drone_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_visit[:, None, None].expand(drone_prev_visit.size(0), 1, embedding.size(2)))


        drone_path_context_8 = torch.cat([drone_path_context_7,drone_prev_visit_embedding], dim=1).mean(1)

        return drone_path_context_8.squeeze()
    
    def get_path_context_10(self, drone, embedding):
    

        drone_prev_10_a = self.drone_prev_10_a.clone().cuda()
        drone_prev_10_visit = drone_prev_10_a[torch.arange(drone_prev_10_a.size(0)), drone]
        drone_prev_10_visit_embedding = torch.gather(
            embedding, 1, drone_prev_10_visit[:, None, None].expand(drone_prev_10_visit.size(0), 1, embedding.size(2))
        )

        drone_prev_9_a = self.drone_prev_9_a.clone().cuda()
        drone_prev_9_visit = drone_prev_9_a[torch.arange(drone_prev_9_a.size(0)), drone]
        drone_prev_9_visit_embedding = torch.gather(
            embedding, 1, drone_prev_9_visit[:, None, None].expand(drone_prev_9_visit.size(0), 1, embedding.size(2))
        )
        
        drone_path_context_1 = torch.cat([drone_prev_10_visit_embedding, drone_prev_9_visit_embedding], dim=1).mean(1)[:,None,:]


        drone_prev_8_a = self.drone_prev_8_a.clone().cuda()
        drone_prev_8_visit = drone_prev_8_a[torch.arange(drone_prev_8_a.size(0)), drone]
        drone_prev_8_visit_embedding = torch.gather(
            embedding, 1, drone_prev_8_visit[:, None, None].expand(drone_prev_8_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_2 = torch.cat([drone_path_context_1,drone_prev_8_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_7_a = self.drone_prev_7_a.clone().cuda()
        drone_prev_7_visit = drone_prev_7_a[torch.arange(drone_prev_7_a.size(0)), drone]
        drone_prev_7_visit_embedding = torch.gather(
            embedding, 1, drone_prev_7_visit[:, None, None].expand(drone_prev_7_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_3 = torch.cat([drone_path_context_2,drone_prev_7_visit_embedding], dim=1).mean(1)[:,None,:]


        drone_prev_6_a = self.drone_prev_6_a.clone().cuda()
        drone_prev_6_visit = drone_prev_6_a[torch.arange(drone_prev_6_a.size(0)), drone]
        drone_prev_6_visit_embedding = torch.gather(
            embedding, 1, drone_prev_6_visit[:, None, None].expand(drone_prev_6_visit.size(0), 1, embedding.size(2))
        )


        drone_path_context_4 = torch.cat([drone_path_context_3,drone_prev_6_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_5_a = self.drone_prev_5_a.clone().cuda()
        drone_prev_5_visit = drone_prev_5_a[torch.arange(drone_prev_5_a.size(0)), drone]
        drone_prev_5_visit_embedding = torch.gather(
            embedding, 1, drone_prev_5_visit[:, None, None].expand(drone_prev_5_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_5 = torch.cat([drone_path_context_4,drone_prev_5_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_4_a = self.drone_prev_4_a.clone().cuda()
        drone_prev_4_visit = drone_prev_4_a[torch.arange(drone_prev_4_a.size(0)), drone]
        drone_prev_4_visit_embedding = torch.gather(
            embedding, 1, drone_prev_4_visit[:, None, None].expand(drone_prev_4_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_6 = torch.cat([drone_path_context_5,drone_prev_4_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_3_a = self.drone_prev_3_a.clone().cuda()
        drone_prev_3_visit = drone_prev_3_a[torch.arange(drone_prev_3_a.size(0)), drone]
        drone_prev_3_visit_embedding = torch.gather(embedding, 1, drone_prev_3_visit[:, None, None].expand(drone_prev_3_visit.size(0), 1, embedding.size(2)))

        drone_path_context_7 = torch.cat([drone_path_context_6,drone_prev_3_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_prev_a = self.drone_prev_prev_a.clone().cuda()
        drone_prev_prev_visit = drone_prev_prev_a[torch.arange(drone_prev_prev_a.size(0)), drone]
        drone_prev_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_prev_visit[:, None, None].expand(drone_prev_prev_visit.size(0), 1, embedding.size(2)))

        drone_path_context_8 = torch.cat([drone_path_context_7,drone_prev_prev_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_a = self.drone_prev_a.clone().cuda()
        drone_prev_visit = drone_prev_a[torch.arange(drone_prev_a.size(0)), drone]
        drone_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_visit[:, None, None].expand(drone_prev_visit.size(0), 1, embedding.size(2)))


        drone_path_context_9 = torch.cat([drone_path_context_8,drone_prev_visit_embedding], dim=1).mean(1)

        return drone_path_context_9.squeeze()    

    def get_path_context_11(self, drone, embedding):
    
        drone_prev_11_a = self.drone_prev_11_a.clone().cuda()
        drone_prev_11_visit = drone_prev_11_a[torch.arange(drone_prev_11_a.size(0)), drone]
        drone_prev_11_visit_embedding = torch.gather(
            embedding, 1, drone_prev_11_visit[:, None, None].expand(drone_prev_11_visit.size(0), 1, embedding.size(2))
        )

        drone_prev_10_a = self.drone_prev_10_a.clone().cuda()
        drone_prev_10_visit = drone_prev_10_a[torch.arange(drone_prev_10_a.size(0)), drone]
        drone_prev_10_visit_embedding = torch.gather(
            embedding, 1, drone_prev_10_visit[:, None, None].expand(drone_prev_10_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_1 = torch.cat([drone_prev_11_visit_embedding, drone_prev_10_visit_embedding], dim=1).mean(1)[:,None,:]


        drone_prev_9_a = self.drone_prev_9_a.clone().cuda()
        drone_prev_9_visit = drone_prev_9_a[torch.arange(drone_prev_9_a.size(0)), drone]
        drone_prev_9_visit_embedding = torch.gather(
            embedding, 1, drone_prev_9_visit[:, None, None].expand(drone_prev_9_visit.size(0), 1, embedding.size(2))
        )
        
        drone_path_context_2 = torch.cat([drone_path_context_1,drone_prev_9_visit_embedding], dim=1).mean(1)[:,None,:]


        drone_prev_8_a = self.drone_prev_8_a.clone().cuda()
        drone_prev_8_visit = drone_prev_8_a[torch.arange(drone_prev_8_a.size(0)), drone]
        drone_prev_8_visit_embedding = torch.gather(
            embedding, 1, drone_prev_8_visit[:, None, None].expand(drone_prev_8_visit.size(0), 1, embedding.size(2))
        )
 
        drone_path_context_3 = torch.cat([drone_path_context_2,drone_prev_8_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_7_a = self.drone_prev_7_a.clone().cuda()
        drone_prev_7_visit = drone_prev_7_a[torch.arange(drone_prev_7_a.size(0)), drone]
        drone_prev_7_visit_embedding = torch.gather(
            embedding, 1, drone_prev_7_visit[:, None, None].expand(drone_prev_7_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_4 = torch.cat([drone_path_context_3,drone_prev_7_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_6_a = self.drone_prev_6_a.clone().cuda()
        drone_prev_6_visit = drone_prev_6_a[torch.arange(drone_prev_6_a.size(0)), drone]
        drone_prev_6_visit_embedding = torch.gather(
            embedding, 1, drone_prev_6_visit[:, None, None].expand(drone_prev_6_visit.size(0), 1, embedding.size(2))
        )
 
        drone_path_context_5 = torch.cat([drone_path_context_4,drone_prev_6_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_5_a = self.drone_prev_5_a.clone().cuda()
        drone_prev_5_visit = drone_prev_5_a[torch.arange(drone_prev_5_a.size(0)), drone]
        drone_prev_5_visit_embedding = torch.gather(
            embedding, 1, drone_prev_5_visit[:, None, None].expand(drone_prev_5_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_6 = torch.cat([drone_path_context_5,drone_prev_5_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_4_a = self.drone_prev_4_a.clone().cuda()
        drone_prev_4_visit = drone_prev_4_a[torch.arange(drone_prev_4_a.size(0)), drone]
        drone_prev_4_visit_embedding = torch.gather(
            embedding, 1, drone_prev_4_visit[:, None, None].expand(drone_prev_4_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_7 = torch.cat([drone_path_context_6,drone_prev_4_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_3_a = self.drone_prev_3_a.clone().cuda()
        drone_prev_3_visit = drone_prev_3_a[torch.arange(drone_prev_3_a.size(0)), drone]
        drone_prev_3_visit_embedding = torch.gather(embedding, 1, drone_prev_3_visit[:, None, None].expand(drone_prev_3_visit.size(0), 1, embedding.size(2)))

        drone_path_context_8 = torch.cat([drone_path_context_7,drone_prev_3_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_prev_a = self.drone_prev_prev_a.clone().cuda()
        drone_prev_prev_visit = drone_prev_prev_a[torch.arange(drone_prev_prev_a.size(0)), drone]
        drone_prev_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_prev_visit[:, None, None].expand(drone_prev_prev_visit.size(0), 1, embedding.size(2)))

        drone_path_context_9 = torch.cat([drone_path_context_8,drone_prev_prev_visit_embedding], dim=1).mean(1)[:,None,:]

        drone_prev_a = self.drone_prev_a.clone().cuda()
        drone_prev_visit = drone_prev_a[torch.arange(drone_prev_a.size(0)), drone]
        drone_prev_visit_embedding = torch.gather(embedding, 1, drone_prev_visit[:, None, None].expand(drone_prev_visit.size(0), 1, embedding.size(2)))

        drone_path_context_10 = torch.cat([drone_path_context_9,drone_prev_visit_embedding], dim=1).mean(1)

        return drone_path_context_10.squeeze()  



    def get_path_context_12(self, drone, embedding):
    
        drone_prev_12_a = self.drone_prev_12_a.clone().cuda()
        drone_prev_12_visit = drone_prev_12_a[torch.arange(drone_prev_12_a.size(0)), drone]
        drone_prev_12_visit_embedding = torch.gather(
            embedding, 1, drone_prev_12_visit[:, None, None].expand(drone_prev_12_visit.size(0), 1, embedding.size(2))
        )

        drone_prev_11_a = self.drone_prev_11_a.clone().cuda()
        drone_prev_11_visit = drone_prev_11_a[torch.arange(drone_prev_11_a.size(0)), drone]
        drone_prev_11_visit_embedding = torch.gather(
            embedding, 1, drone_prev_11_visit[:, None, None].expand(drone_prev_11_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_1 = torch.cat([drone_prev_12_visit_embedding, drone_prev_11_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_10_a = self.drone_prev_10_a.clone().cuda()
        drone_prev_10_visit = drone_prev_10_a[torch.arange(drone_prev_10_a.size(0)), drone]
        drone_prev_10_visit_embedding = torch.gather(
            embedding, 1, drone_prev_10_visit[:, None, None].expand(drone_prev_10_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_2 = torch.cat([drone_path_context_1, drone_prev_10_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_9_a = self.drone_prev_9_a.clone().cuda()
        drone_prev_9_visit = drone_prev_9_a[torch.arange(drone_prev_9_a.size(0)), drone]
        drone_prev_9_visit_embedding = torch.gather(
            embedding, 1, drone_prev_9_visit[:, None, None].expand(drone_prev_9_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_3 = torch.cat([drone_path_context_2, drone_prev_9_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_8_a = self.drone_prev_8_a.clone().cuda()
        drone_prev_8_visit = drone_prev_8_a[torch.arange(drone_prev_8_a.size(0)), drone]
        drone_prev_8_visit_embedding = torch.gather(
            embedding, 1, drone_prev_8_visit[:, None, None].expand(drone_prev_8_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_4 = torch.cat([drone_path_context_3, drone_prev_8_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_7_a = self.drone_prev_7_a.clone().cuda()
        drone_prev_7_visit = drone_prev_7_a[torch.arange(drone_prev_7_a.size(0)), drone]
        drone_prev_7_visit_embedding = torch.gather(
            embedding, 1, drone_prev_7_visit[:, None, None].expand(drone_prev_7_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_5 = torch.cat([drone_path_context_4, drone_prev_7_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_6_a = self.drone_prev_6_a.clone().cuda()
        drone_prev_6_visit = drone_prev_6_a[torch.arange(drone_prev_6_a.size(0)), drone]
        drone_prev_6_visit_embedding = torch.gather(
            embedding, 1, drone_prev_6_visit[:, None, None].expand(drone_prev_6_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_6 = torch.cat([drone_path_context_5, drone_prev_6_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_5_a = self.drone_prev_5_a.clone().cuda()
        drone_prev_5_visit = drone_prev_5_a[torch.arange(drone_prev_5_a.size(0)), drone]
        drone_prev_5_visit_embedding = torch.gather(
            embedding, 1, drone_prev_5_visit[:, None, None].expand(drone_prev_5_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_7 = torch.cat([drone_path_context_6, drone_prev_5_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_4_a = self.drone_prev_4_a.clone().cuda()
        drone_prev_4_visit = drone_prev_4_a[torch.arange(drone_prev_4_a.size(0)), drone]
        drone_prev_4_visit_embedding = torch.gather(
            embedding, 1, drone_prev_4_visit[:, None, None].expand(drone_prev_4_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_8 = torch.cat([drone_path_context_7, drone_prev_4_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_3_a = self.drone_prev_3_a.clone().cuda()
        drone_prev_3_visit = drone_prev_3_a[torch.arange(drone_prev_3_a.size(0)), drone]
        drone_prev_3_visit_embedding = torch.gather(
            embedding, 1, drone_prev_3_visit[:, None, None].expand(drone_prev_3_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_9 = torch.cat([drone_path_context_8, drone_prev_3_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_prev_a = self.drone_prev_prev_a.clone().cuda()
        drone_prev_prev_visit = drone_prev_prev_a[torch.arange(drone_prev_prev_a.size(0)), drone]
        drone_prev_prev_visit_embedding = torch.gather(
            embedding, 1, drone_prev_prev_visit[:, None, None].expand(drone_prev_prev_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_10 = torch.cat([drone_path_context_9, drone_prev_prev_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_a = self.drone_prev_a.clone().cuda()
        drone_prev_visit = drone_prev_a[torch.arange(drone_prev_a.size(0)), drone]
        drone_prev_visit_embedding = torch.gather(
            embedding, 1, drone_prev_visit[:, None, None].expand(drone_prev_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_11 = torch.cat([drone_path_context_10, drone_prev_visit_embedding], dim=1).mean(1)

        return drone_path_context_11.squeeze()

    def get_path_context_13(self, drone, embedding):
        drone_prev_13_a = self.drone_prev_13_a.clone().cuda()
        drone_prev_13_visit = drone_prev_13_a[torch.arange(drone_prev_13_a.size(0)), drone]
        drone_prev_13_visit_embedding = torch.gather(
            embedding, 1, drone_prev_13_visit[:, None, None].expand(drone_prev_13_visit.size(0), 1, embedding.size(2))
        )

        drone_prev_12_a = self.drone_prev_12_a.clone().cuda()
        drone_prev_12_visit = drone_prev_12_a[torch.arange(drone_prev_12_a.size(0)), drone]
        drone_prev_12_visit_embedding = torch.gather(
            embedding, 1, drone_prev_12_visit[:, None, None].expand(drone_prev_12_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_1 = torch.cat([drone_prev_13_visit_embedding, drone_prev_12_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_11_a = self.drone_prev_11_a.clone().cuda()
        drone_prev_11_visit = drone_prev_11_a[torch.arange(drone_prev_11_a.size(0)), drone]
        drone_prev_11_visit_embedding = torch.gather(
            embedding, 1, drone_prev_11_visit[:, None, None].expand(drone_prev_11_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_2 = torch.cat([drone_path_context_1, drone_prev_11_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_10_a = self.drone_prev_10_a.clone().cuda()
        drone_prev_10_visit = drone_prev_10_a[torch.arange(drone_prev_10_a.size(0)), drone]
        drone_prev_10_visit_embedding = torch.gather(
            embedding, 1, drone_prev_10_visit[:, None, None].expand(drone_prev_10_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_3 = torch.cat([drone_path_context_2, drone_prev_10_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_9_a = self.drone_prev_9_a.clone().cuda()
        drone_prev_9_visit = drone_prev_9_a[torch.arange(drone_prev_9_a.size(0)), drone]
        drone_prev_9_visit_embedding = torch.gather(
            embedding, 1, drone_prev_9_visit[:, None, None].expand(drone_prev_9_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_4 = torch.cat([drone_path_context_3, drone_prev_9_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_8_a = self.drone_prev_8_a.clone().cuda()
        drone_prev_8_visit = drone_prev_8_a[torch.arange(drone_prev_8_a.size(0)), drone]
        drone_prev_8_visit_embedding = torch.gather(
            embedding, 1, drone_prev_8_visit[:, None, None].expand(drone_prev_8_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_5 = torch.cat([drone_path_context_4, drone_prev_8_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_7_a = self.drone_prev_7_a.clone().cuda()
        drone_prev_7_visit = drone_prev_7_a[torch.arange(drone_prev_7_a.size(0)), drone]
        drone_prev_7_visit_embedding = torch.gather(
            embedding, 1, drone_prev_7_visit[:, None, None].expand(drone_prev_7_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_6 = torch.cat([drone_path_context_5, drone_prev_7_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_6_a = self.drone_prev_6_a.clone().cuda()
        drone_prev_6_visit = drone_prev_6_a[torch.arange(drone_prev_6_a.size(0)), drone]
        drone_prev_6_visit_embedding = torch.gather(
            embedding, 1, drone_prev_6_visit[:, None, None].expand(drone_prev_6_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_7 = torch.cat([drone_path_context_6, drone_prev_6_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_5_a = self.drone_prev_5_a.clone().cuda()
        drone_prev_5_visit = drone_prev_5_a[torch.arange(drone_prev_5_a.size(0)), drone]
        drone_prev_5_visit_embedding = torch.gather(
            embedding, 1, drone_prev_5_visit[:, None, None].expand(drone_prev_5_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_8 = torch.cat([drone_path_context_7, drone_prev_5_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_4_a = self.drone_prev_4_a.clone().cuda()
        drone_prev_4_visit = drone_prev_4_a[torch.arange(drone_prev_4_a.size(0)), drone]
        drone_prev_4_visit_embedding = torch.gather(
            embedding, 1, drone_prev_4_visit[:, None, None].expand(drone_prev_4_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_9 = torch.cat([drone_path_context_8, drone_prev_4_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_3_a = self.drone_prev_3_a.clone().cuda()
        drone_prev_3_visit = drone_prev_3_a[torch.arange(drone_prev_3_a.size(0)), drone]
        drone_prev_3_visit_embedding = torch.gather(
            embedding, 1, drone_prev_3_visit[:, None, None].expand(drone_prev_3_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_10 = torch.cat([drone_path_context_9, drone_prev_3_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_prev_a = self.drone_prev_prev_a.clone().cuda()
        drone_prev_prev_visit = drone_prev_prev_a[torch.arange(drone_prev_prev_a.size(0)), drone]
        drone_prev_prev_visit_embedding = torch.gather(
            embedding, 1, drone_prev_prev_visit[:, None, None].expand(drone_prev_prev_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_11 = torch.cat([drone_path_context_10, drone_prev_prev_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_a = self.drone_prev_a.clone().cuda()
        drone_prev_visit = drone_prev_a[torch.arange(drone_prev_a.size(0)), drone]
        drone_prev_visit_embedding = torch.gather(
            embedding, 1, drone_prev_visit[:, None, None].expand(drone_prev_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_12 = torch.cat([drone_path_context_11, drone_prev_visit_embedding], dim=1).mean(1)

        return drone_path_context_12.squeeze()

    def get_path_context_14(self, drone, embedding):
        drone_prev_14_a = self.drone_prev_14_a.clone().cuda()
        drone_prev_14_visit = drone_prev_14_a[torch.arange(drone_prev_14_a.size(0)), drone]
        drone_prev_14_visit_embedding = torch.gather(
            embedding, 1, drone_prev_14_visit[:, None, None].expand(drone_prev_14_visit.size(0), 1, embedding.size(2))
        )

        drone_prev_13_a = self.drone_prev_13_a.clone().cuda()
        drone_prev_13_visit = drone_prev_13_a[torch.arange(drone_prev_13_a.size(0)), drone]
        drone_prev_13_visit_embedding = torch.gather(
            embedding, 1, drone_prev_13_visit[:, None, None].expand(drone_prev_13_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_1 = torch.cat([drone_prev_14_visit_embedding, drone_prev_13_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_12_a = self.drone_prev_12_a.clone().cuda()
        drone_prev_12_visit = drone_prev_12_a[torch.arange(drone_prev_12_a.size(0)), drone]
        drone_prev_12_visit_embedding = torch.gather(
            embedding, 1, drone_prev_12_visit[:, None, None].expand(drone_prev_12_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_2 = torch.cat([drone_path_context_1, drone_prev_12_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_11_a = self.drone_prev_11_a.clone().cuda()
        drone_prev_11_visit = drone_prev_11_a[torch.arange(drone_prev_11_a.size(0)), drone]
        drone_prev_11_visit_embedding = torch.gather(
            embedding, 1, drone_prev_11_visit[:, None, None].expand(drone_prev_11_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_3 = torch.cat([drone_path_context_2, drone_prev_11_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_10_a = self.drone_prev_10_a.clone().cuda()
        drone_prev_10_visit = drone_prev_10_a[torch.arange(drone_prev_10_a.size(0)), drone]
        drone_prev_10_visit_embedding = torch.gather(
            embedding, 1, drone_prev_10_visit[:, None, None].expand(drone_prev_10_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_4 = torch.cat([drone_path_context_3, drone_prev_10_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_9_a = self.drone_prev_9_a.clone().cuda()
        drone_prev_9_visit = drone_prev_9_a[torch.arange(drone_prev_9_a.size(0)), drone]
        drone_prev_9_visit_embedding = torch.gather(
            embedding, 1, drone_prev_9_visit[:, None, None].expand(drone_prev_9_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_5 = torch.cat([drone_path_context_4, drone_prev_9_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_8_a = self.drone_prev_8_a.clone().cuda()
        drone_prev_8_visit = drone_prev_8_a[torch.arange(drone_prev_8_a.size(0)), drone]
        drone_prev_8_visit_embedding = torch.gather(
            embedding, 1, drone_prev_8_visit[:, None, None].expand(drone_prev_8_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_6 = torch.cat([drone_path_context_5, drone_prev_8_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_7_a = self.drone_prev_7_a.clone().cuda()
        drone_prev_7_visit = drone_prev_7_a[torch.arange(drone_prev_7_a.size(0)), drone]
        drone_prev_7_visit_embedding = torch.gather(
            embedding, 1, drone_prev_7_visit[:, None, None].expand(drone_prev_7_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_7 = torch.cat([drone_path_context_6, drone_prev_7_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_6_a = self.drone_prev_6_a.clone().cuda()
        drone_prev_6_visit = drone_prev_6_a[torch.arange(drone_prev_6_a.size(0)), drone]
        drone_prev_6_visit_embedding = torch.gather(
            embedding, 1, drone_prev_6_visit[:, None, None].expand(drone_prev_6_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_8 = torch.cat([drone_path_context_7, drone_prev_6_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_5_a = self.drone_prev_5_a.clone().cuda()
        drone_prev_5_visit = drone_prev_5_a[torch.arange(drone_prev_5_a.size(0)), drone]
        drone_prev_5_visit_embedding = torch.gather(
            embedding, 1, drone_prev_5_visit[:, None, None].expand(drone_prev_5_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_9 = torch.cat([drone_path_context_8, drone_prev_5_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_4_a = self.drone_prev_4_a.clone().cuda()
        drone_prev_4_visit = drone_prev_4_a[torch.arange(drone_prev_4_a.size(0)), drone]
        drone_prev_4_visit_embedding = torch.gather(
            embedding, 1, drone_prev_4_visit[:, None, None].expand(drone_prev_4_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_10 = torch.cat([drone_path_context_9, drone_prev_4_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_3_a = self.drone_prev_3_a.clone().cuda()
        drone_prev_3_visit = drone_prev_3_a[torch.arange(drone_prev_3_a.size(0)), drone]
        drone_prev_3_visit_embedding = torch.gather(
            embedding, 1, drone_prev_3_visit[:, None, None].expand(drone_prev_3_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_11 = torch.cat([drone_path_context_10, drone_prev_3_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_prev_a = self.drone_prev_prev_a.clone().cuda()
        drone_prev_prev_visit = drone_prev_prev_a[torch.arange(drone_prev_prev_a.size(0)), drone]
        drone_prev_prev_visit_embedding = torch.gather(
            embedding, 1, drone_prev_prev_visit[:, None, None].expand(drone_prev_prev_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_12 = torch.cat([drone_path_context_11, drone_prev_prev_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_a = self.drone_prev_a.clone().cuda()
        drone_prev_visit = drone_prev_a[torch.arange(drone_prev_a.size(0)), drone]
        drone_prev_visit_embedding = torch.gather(
            embedding, 1, drone_prev_visit[:, None, None].expand(drone_prev_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_13 = torch.cat([drone_path_context_12, drone_prev_visit_embedding], dim=1).mean(1)

        return drone_path_context_13.squeeze()

    def get_path_context_15(self, drone, embedding):
        drone_prev_15_a = self.drone_prev_15_a.clone().cuda()
        drone_prev_15_visit = drone_prev_15_a[torch.arange(drone_prev_15_a.size(0)), drone]
        drone_prev_15_visit_embedding = torch.gather(
            embedding, 1, drone_prev_15_visit[:, None, None].expand(drone_prev_15_visit.size(0), 1, embedding.size(2))
        )

        drone_prev_14_a = self.drone_prev_14_a.clone().cuda()
        drone_prev_14_visit = drone_prev_14_a[torch.arange(drone_prev_14_a.size(0)), drone]
        drone_prev_14_visit_embedding = torch.gather(
            embedding, 1, drone_prev_14_visit[:, None, None].expand(drone_prev_14_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_1 = torch.cat([drone_prev_15_visit_embedding, drone_prev_14_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_13_a = self.drone_prev_13_a.clone().cuda()
        drone_prev_13_visit = drone_prev_13_a[torch.arange(drone_prev_13_a.size(0)), drone]
        drone_prev_13_visit_embedding = torch.gather(
            embedding, 1, drone_prev_13_visit[:, None, None].expand(drone_prev_13_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_2 = torch.cat([drone_path_context_1, drone_prev_13_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_12_a = self.drone_prev_12_a.clone().cuda()
        drone_prev_12_visit = drone_prev_12_a[torch.arange(drone_prev_12_a.size(0)), drone]
        drone_prev_12_visit_embedding = torch.gather(
            embedding, 1, drone_prev_12_visit[:, None, None].expand(drone_prev_12_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_3 = torch.cat([drone_path_context_2, drone_prev_12_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_11_a = self.drone_prev_11_a.clone().cuda()
        drone_prev_11_visit = drone_prev_11_a[torch.arange(drone_prev_11_a.size(0)), drone]
        drone_prev_11_visit_embedding = torch.gather(
            embedding, 1, drone_prev_11_visit[:, None, None].expand(drone_prev_11_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_4 = torch.cat([drone_path_context_3, drone_prev_11_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_10_a = self.drone_prev_10_a.clone().cuda()
        drone_prev_10_visit = drone_prev_10_a[torch.arange(drone_prev_10_a.size(0)), drone]
        drone_prev_10_visit_embedding = torch.gather(
            embedding, 1, drone_prev_10_visit[:, None, None].expand(drone_prev_10_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_5 = torch.cat([drone_path_context_4, drone_prev_10_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_9_a = self.drone_prev_9_a.clone().cuda()
        drone_prev_9_visit = drone_prev_9_a[torch.arange(drone_prev_9_a.size(0)), drone]
        drone_prev_9_visit_embedding = torch.gather(
            embedding, 1, drone_prev_9_visit[:, None, None].expand(drone_prev_9_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_6 = torch.cat([drone_path_context_5, drone_prev_9_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_8_a = self.drone_prev_8_a.clone().cuda()
        drone_prev_8_visit = drone_prev_8_a[torch.arange(drone_prev_8_a.size(0)), drone]
        drone_prev_8_visit_embedding = torch.gather(
            embedding, 1, drone_prev_8_visit[:, None, None].expand(drone_prev_8_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_7 = torch.cat([drone_path_context_6, drone_prev_8_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_7_a = self.drone_prev_7_a.clone().cuda()
        drone_prev_7_visit = drone_prev_7_a[torch.arange(drone_prev_7_a.size(0)), drone]
        drone_prev_7_visit_embedding = torch.gather(
            embedding, 1, drone_prev_7_visit[:, None, None].expand(drone_prev_7_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_8 = torch.cat([drone_path_context_7, drone_prev_7_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_6_a = self.drone_prev_6_a.clone().cuda()
        drone_prev_6_visit = drone_prev_6_a[torch.arange(drone_prev_6_a.size(0)), drone]
        drone_prev_6_visit_embedding = torch.gather(
            embedding, 1, drone_prev_6_visit[:, None, None].expand(drone_prev_6_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_9 = torch.cat([drone_path_context_8, drone_prev_6_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_5_a = self.drone_prev_5_a.clone().cuda()
        drone_prev_5_visit = drone_prev_5_a[torch.arange(drone_prev_5_a.size(0)), drone]
        drone_prev_5_visit_embedding = torch.gather(
            embedding, 1, drone_prev_5_visit[:, None, None].expand(drone_prev_5_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_10 = torch.cat([drone_path_context_9, drone_prev_5_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_4_a = self.drone_prev_4_a.clone().cuda()
        drone_prev_4_visit = drone_prev_4_a[torch.arange(drone_prev_4_a.size(0)), drone]
        drone_prev_4_visit_embedding = torch.gather(
            embedding, 1, drone_prev_4_visit[:, None, None].expand(drone_prev_4_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_11 = torch.cat([drone_path_context_10, drone_prev_4_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_3_a = self.drone_prev_3_a.clone().cuda()
        drone_prev_3_visit = drone_prev_3_a[torch.arange(drone_prev_3_a.size(0)), drone]
        drone_prev_3_visit_embedding = torch.gather(
            embedding, 1, drone_prev_3_visit[:, None, None].expand(drone_prev_3_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_12 = torch.cat([drone_path_context_11, drone_prev_3_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_prev_a = self.drone_prev_prev_a.clone().cuda()
        drone_prev_prev_visit = drone_prev_prev_a[torch.arange(drone_prev_prev_a.size(0)), drone]
        drone_prev_prev_visit_embedding = torch.gather(
            embedding, 1, drone_prev_prev_visit[:, None, None].expand(drone_prev_prev_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_13 = torch.cat([drone_path_context_12, drone_prev_prev_visit_embedding], dim=1).mean(1)[:, None, :]

        drone_prev_a = self.drone_prev_a.clone().cuda()
        drone_prev_visit = drone_prev_a[torch.arange(drone_prev_a.size(0)), drone]
        drone_prev_visit_embedding = torch.gather(
            embedding, 1, drone_prev_visit[:, None, None].expand(drone_prev_visit.size(0), 1, embedding.size(2))
        )

        drone_path_context_14 = torch.cat([drone_path_context_13, drone_prev_visit_embedding], dim=1).mean(1)

        return drone_path_context_14.squeeze()



    def get_current_node(self):
        return self.drone_prev_a

    def get_acc_late(self):
        return self.drone_acc_late


    def get_acc_lengths(self):
        return self.lengths


    def get_mask(self, drone,depot_num,charge_station_num):


        all_drone_delivery = self.drone_masks # 512* n_drone * n_loc
        delivery = all_drone_delivery.gather(1, drone[:,None,None].expand(all_drone_delivery .size(0), 1,
                                                                       all_drone_delivery .size(2)))  # 512*1*n_loc
        depot_mask = delivery[:, :, :depot_num]
        charge_station_mask = delivery[:, :, depot_num:depot_num+charge_station_num]
        delivery_mask = delivery[:, :, depot_num+charge_station_num:]


        cur_drone_rema_cap = self.drone_rema_capa.gather(1, drone[:,None,None].expand(self.drone_rema_capa.size(0), 1,self.drone_rema_capa.size(2)))

        cur_drone_time = self.drone_cur_time.gather(1, drone[:,None,None].expand(self.drone_cur_time.size(0), 1,self.drone_cur_time.size(2)))

        hidden_tasks = cur_drone_time < self.aprs[:,:,depot_num+charge_station_num:]
        overloaded_tasks = cur_drone_rema_cap < self.package_weight[:,:,depot_num+charge_station_num:]
        visited_loc = self.visited_[:, :, depot_num + charge_station_num:]  # [batch_size, 1, n_loc]

        mask_loc = visited_loc.to(self.drone_masks.device) | (1 - delivery_mask) | hidden_tasks | overloaded_tasks

        non_cus_index = mask_loc.all(-1).squeeze()


        depot_mask[non_cus_index] = 0


        drone_remain_energy = self.drone_remain_energy.gather(1, drone[:,None,None].expand(self.drone_remain_energy.size(0), 1,self.drone_remain_energy.size(2)))
        drone_prev_a = self.drone_prev_a.gather(1, drone[:,None].expand(self.drone_prev_a.size(0),1))
        coordinate_of_drone_prev_a = self.locs.gather(1, drone_prev_a[:,None].expand(self.locs.size(0),1 , self.locs.size(2)))
        task_locs = self.locs[:,depot_num+charge_station_num:,:]
        needed_energy = (coordinate_of_drone_prev_a - task_locs).norm(p=2, dim=-1) * 0.3

        over_energy_tasks = drone_remain_energy < needed_energy[:,None,:]

        mask_loc_considering_energy = mask_loc | over_energy_tasks

        need_charge = mask_loc_considering_energy.all(-1).squeeze()
        tt = need_charge.sum()

        charge_station_mask[need_charge] = 0
        depot_mask[need_charge] = 0



        t = need_charge.sum()
        y = non_cus_index.sum()


        charge_station_mask[non_cus_index] = 1

        mask = torch.cat((depot_mask,charge_station_mask,mask_loc_considering_energy),dim=-1)

        return mask > 0, non_cus_index,need_charge

    def get_drone_mask(self,num_drone):



        drone_mask_l = []
        for i in range (num_drone):

            mask_base_= self.drone_masks[:, i, :][:, None, :]
            if self.visited_.dtype == torch.uint8:
                visited_loc = self.visited_  # [batch_size, 1, n_loc]
            else:
                visited_loc = self.visited_[:, None, :]  # [batch_size, 1, n_loc]

            mask_drone_ = visited_loc.to(mask_base_.device) | (1 - mask_base_)

            drone_mask_ = mask_drone_.sum(-1) == mask_drone_.size(-1)
            drone_mask_l.append(drone_mask_)



        drone_mask = torch.cat(drone_mask_l,1) # 512*3



        all_done_index = self.visited_.all(-1).squeeze()
        drone_mask[all_done_index] = 0

        return drone_mask
    
    def construct_solutions(self, actions):
        return actions
